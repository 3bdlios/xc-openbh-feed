from pathlib import Path
p=Path(__file__).parent
s=(p/'xc-audiod.r11.c').read_text()
s=s.replace('#include <libswresample/swresample.h>','#include <libswresample/swresample.h>\n#include "sync_control.h"')
s=s.replace('int64_t t_next;int pass,fixes,ns,drop;int offs[9];','int64_t t_next,startup_begin;struct xc_sync sync;int startup_dropped,xruns;')
s=s.replace('DMX_SET_BUFFER_SIZE,512*1024','DMX_SET_BUFFER_SIZE,2*1024*1024')
s=s.replace('av_rescale_rnd(swr_get_delay(e->swr,f->sample_rate)+f->nb_samples,48000,f->sample_rate,AV_ROUND_UP)','swr_get_out_samples(e->swr,f->nb_samples)')
# Retain the current 2-second headroom in this isolated first test. No new
# global video buffering policy, kernel module or image settings are introduced.
a=s.index('static int cmp_int(');b=s.index('static int emit_frame(',a)
s=s[:a]+'''static int clock_read(const char *name,uint32_t *value){
 char path[128];snprintf(path,sizeof(path),"/sys/class/tsync/%s",name);
 FILE *f=fopen(path,"r");if(!f)return -1;unsigned x;int ok=fscanf(f,"%x",&x)==1;fclose(f);if(!ok||!x)return -1;*value=x;return 0;
}
/* Align only before the first audible sample. A bounded wait permits decoding
 * and channel changes to recover even when no valid picture clock arrives. */
static int startup_align(struct engine *e,int64_t pts,int count){
 if(!e->fileclock||e->started)return 0;
 if(!e->startup_begin)e->startup_begin=now_ms();
 uint32_t last_p=0,last_v=0;int64_t last_change=now_ms();int advancing=0;
 while(!quit){
  struct state s;if(!current(e,&s))return -1;
  if(s.play==2){usleep(10000);continue;}
  int64_t now=now_ms();uint32_t p=0,v=0;
  if(now-e->startup_begin>4500){
   fprintf(stderr,"XC r12 startup deadline; starting without hard live correction, skipped=%d samples\\n",e->startup_dropped);return 0;
  }
  if(clock_read("pts_pcrscr",&p)||clock_read("pts_video",&v)){usleep(5000);continue;}
  if(v!=last_v){last_v=v;last_change=now;}
  if(last_p&&xc_delta(p,last_p)>0&&xc_delta(p,last_p)<18000)advancing++;
  last_p=p;
  if(advancing<2||now-last_change>250||abs(xc_delta(p,v))>90000){usleep(5000);continue;}
  int32_t error=xc_delta(p,(uint32_t)pts);
  if(error>2700){
   int64_t skip=((int64_t)error-900)*48000/90000;
   if(skip>count)skip=count;
   e->startup_dropped+=(int)skip;
   return (int)skip;
  }
  if(error<-900){usleep(5000);continue;}
  fprintf(stderr,"XC r12 startup aligned: %+d ms, pre-start skipped=%d samples\\n",error/90,e->startup_dropped);
  return 0;
 }
 return -1;
}
static void align_check(struct engine *e,int64_t heard){
 if(!e->fileclock||!e->swr)return;
 int64_t t=now_ms();if(t<e->t_next)return;e->t_next=t+100;
 uint32_t p,v;
 if(clock_read("pts_pcrscr",&p)||clock_read("pts_video",&v)){
  memset(&e->sync,0,sizeof(e->sync));swr_set_compensation(e->swr,0,0);return;
 }
 int result=xc_observe(&e->sync,t,p,v,(uint32_t)heard);
 if(result<0){swr_set_compensation(e->swr,0,0);return;}
 if(result>0){
  int delta=(int)((int64_t)e->sync.ppm*48000*5/1000000);
  int r=swr_set_compensation(e->swr,delta,48000*5);
  fprintf(stderr,"XC r12 soft sync: error=%+d ms rate=%+d ppm rc=%d\\n",xc_delta(p,(uint32_t)heard)/90,e->sync.ppm,r);
 }
}
''' + s[b:]
s=s.replace('e->nextpts=pts+(int64_t)count*90000/48000;','''/* Source media time must not advance by the compensated output length. */
 int64_t content_ticks=(int64_t)f->nb_samples*90000/f->sample_rate;
 e->nextpts=pts+content_ticks;
 int first=startup_align(e,pts,count);
 if(first<0){av_free(buf);return -1;}
 if(first>=count){av_free(buf);return 0;}''')
s=s.replace('int offset=0;while(offset<count','int offset=first;while(offset<count')
s=s.replace('if(e->drop){int k=e->drop<count-offset?e->drop:count-offset;e->drop-=k;offset+=k;continue;}','')
s=s.replace('if(n<0){if(snd_pcm_recover(e->pcm,n,1)<0){av_free(buf);return -1;}continue;}', '''if(n<0){
  if(n==-EPIPE){e->xruns++;fprintf(stderr,"XC r12 ALSA underrun #%d gen=%u\\n",e->xruns,s.gen);}
  if(snd_pcm_recover(e->pcm,n,1)<0){av_free(buf);return -1;}
  memset(&e->sync,0,sizeof(e->sync));swr_set_compensation(e->swr,0,0);continue;
 }''')
s=s.replace('int64_t heard=pts+((int64_t)offset-delay)*90000/48000;', '''if(delay<0||delay>48000){memset(&e->sync,0,sizeof(e->sync));delay=0;}
 int64_t heard=pts+((int64_t)offset-delay)*content_ticks/(count?count:1);''')
s=s.replace('e->t_next=now_ms()+2500','e->t_next=now_ms()+1000')
(p/'xc-audiod.c').write_text(s)
assert 'e->drop' not in s and 'static int16_t zero' not in s
