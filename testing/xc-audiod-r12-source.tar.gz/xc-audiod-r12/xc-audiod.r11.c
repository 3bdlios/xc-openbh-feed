/* SPDX-License-Identifier: GPL-2.0-or-later */
/* XC native DVB audio backend: application control stays on audio0. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <math.h>
#include <sys/ioctl.h>
#include <linux/dvb/dmx.h>
#include <alsa/asoundlib.h>
#include <libavcodec/avcodec.h>
#include <libavutil/channel_layout.h>
#include <libswresample/swresample.h>
struct state {unsigned gen;int demux,pid,codec,play,source,mute;unsigned left,right;int channel;};
static volatile sig_atomic_t quit;
static void stop(int n){(void)n;quit=1;}
static int state_read(struct state *s){FILE *f=fopen("/proc/xc_audio","r");int n;if(!f)return -1;n=fscanf(f,"%u %d %d %d %d %d %d %u %u %d",&s->gen,&s->demux,&s->pid,&s->codec,&s->play,&s->source,&s->mute,&s->left,&s->right,&s->channel);fclose(f);return n==10?0:-1;}
static int syswrite(const char *path,const char *v){int fd=open(path,O_WRONLY|O_CLOEXEC);if(fd<0)return -1;int n=write(fd,v,strlen(v));close(fd);return n<0?-1:0;}
static enum AVCodecID codec_id(int bypass){switch(bypass){case 1:return AV_CODEC_ID_MP2;case 0:return AV_CODEC_ID_AC3;case 8:return AV_CODEC_ID_AAC;/* Enigma2 AAC-HE (9) is DVB stream type 0x11: LATM/LOAS, not ADTS */case 9:return AV_CODEC_ID_AAC_LATM;case 2:case 16:return AV_CODEC_ID_DTS;case 34:return AV_CODEC_ID_EAC3;default:return AV_CODEC_ID_NONE;}}
struct engine {struct state initial;int fd;AVCodecContext *dec;AVCodecParserContext *parser;AVFrame *frame;AVPacket *packet;SwrContext *swr;snd_pcm_t *pcm;int rate,format,channels,started,paused,cc,cc_valid,fileclock,audiomaster;uint8_t header[272];int hn,need;int64_t pts,nextpts;
 int64_t t_next;int pass,fixes,ns,drop;int offs[9];};
static void engine_close(struct engine *e){if(e->fd>=0){ioctl(e->fd,DMX_STOP);close(e->fd);}if(e->pcm){snd_pcm_drop(e->pcm);snd_pcm_close(e->pcm);}swr_free(&e->swr);avcodec_free_context(&e->dec);if(e->parser)av_parser_close(e->parser);av_frame_free(&e->frame);av_packet_free(&e->packet);memset(e,0,sizeof(*e));e->fd=-1;}
/* How far the stream relay / file input may run ahead of the picture clock (aml_hardware_dmx, ms):
 * the default 1 s is about the sound's own lag in relay streams, so the sound came late. 2 s costs
 * one more second before a relay channel shows. */
static void hiu_lead(void){syswrite("/sys/module/aml_hardware_dmx/parameters/xc_es_start_ms","2000");syswrite("/sys/module/aml_hardware_dmx/parameters/xc_es_lead_ms","2000");}
static int engine_open(struct engine *e,struct state *s){char path[128];enum AVCodecID id=codec_id(s->codec);const AVCodec *c=avcodec_find_decoder(id);if(!c)return -1;e->initial=*s;e->pts=e->nextpts=AV_NOPTS_VALUE;
 /* The HIU demux is fed by relay/file playback. Its XC video clock is
  * authoritative; audio must not repeatedly realign that same clock. */
 snprintf(path,sizeof(path),"/sys/class/stb/demux%d_source",s->demux);
 FILE *source=fopen(path,"r");if(source){char name[32]={0};if(fgets(name,sizeof(name),source))e->fileclock=!strncmp(name,"hiu",3);fclose(source);}
 e->dec=avcodec_alloc_context3(c);e->parser=av_parser_init(id);e->frame=av_frame_alloc();e->packet=av_packet_alloc();if(!e->dec||!e->parser||!e->frame||!e->packet)return -1;e->dec->pkt_timebase=(AVRational){1,90000};e->dec->thread_count=1;if(avcodec_open2(e->dec,c,NULL)<0)return -1;
 snprintf(path,sizeof(path),"/dev/dvb/adapter0/demux%d",s->demux);e->fd=open(path,O_RDONLY|O_NONBLOCK|O_CLOEXEC);if(e->fd<0)return -1;ioctl(e->fd,DMX_SET_BUFFER_SIZE,512*1024);struct dmx_pes_filter_params p={.pid=s->pid,.input=DMX_IN_FRONTEND,.output=DMX_OUT_TSDEMUX_TAP,.pes_type=DMX_PES_OTHER,.flags=DMX_IMMEDIATE_START};if(ioctl(e->fd,DMX_SET_PES_FILTER,&p)<0)return -1;
 fprintf(stderr,"XC audio generation=%u demux=%d pid=%d bypass=%d decoder=%s\n",s->gen,s->demux,s->pid,s->codec,c->name);return 0;}
static int current(struct engine *e,struct state *s){return !state_read(s)&&s->gen==e->initial.gen&&s->pid==e->initial.pid&&s->play!=0;}
/* Amlogic's discontinuity timer may restore AMASTER after AUDIO_START.
 * Restrict correction to an active HIU engine; tuner playback keeps its policy. */
static void file_clock_guard(struct engine *e){
 if(!e->fileclock||!e->started||e->audiomaster)return;
 FILE *f=fopen("/sys/class/tsync/mode","r");int mode=-1;
 if(f){if(fscanf(f,"%d",&mode)!=1)mode=-1;fclose(f);}
 if(mode>0)syswrite("/sys/class/tsync/mode","0");
}
static int64_t now_ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (int64_t)t.tv_sec*1000+t.tv_nsec/1000000;}
static int cmp_int(const void *a,const void *b){return *(const int*)a-*(const int*)b;}
/* HIU playback (stream relay, files) runs on the XC video clock and nothing lined the sound up with
 * it: the sound played as it arrived, and stream relay sound arrives up to ~1 s behind its picture
 * (measured -390..+400 ms on one channel, different on every zap). With 2 s of input lead (see
 * hiu_lead) it is always there early, so it can be put on the picture clock: once the start has
 * settled measure picture minus sound over ~1 s and correct it in one go, silence when the sound
 * leads, dropping when it trails. A fine pass 3 s later, then a check every 5 s. */
static void align_check(struct engine *e,int64_t heard){
 if(!e->fileclock||e->audiomaster||e->fixes>=8||e->drop)return;
 int64_t t=now_ms();if(t<e->t_next)return;e->t_next=t+100;
 FILE *f=fopen("/sys/class/tsync/pts_video","r");unsigned v=0;if(f){if(fscanf(f,"%x",&v)!=1)v=0;fclose(f);}
 if(!v){e->ns=0;return;}
 int d=(int)(int32_t)(v-(uint32_t)heard);if(d>10*90000||d<-10*90000){e->ns=0;return;}
 e->offs[e->ns++]=d;if(e->ns<9)return;e->ns=0;
 qsort(e->offs,9,sizeof(int),cmp_int);int m=e->offs[4],lim=(e->pass==0?40:e->pass==1?60:80)*90;
 e->t_next=t+(++e->pass<2?3000:5000);
 if(m>-lim&&m<lim){if(e->pass<=2)fprintf(stderr,"XC audio sync %+d ms, ok\n",m/90);return;}
 e->fixes++;
 if(m>2*90000)m=2*90000;if(m<-2*90000)m=-2*90000;
 int frames=(int)((int64_t)(m<0?-m:m)*48000/90000);
 fprintf(stderr,"XC audio sync %+d ms: %s %d ms of sound\n",m/90,m>0?"dropping":"adding",frames*1000/48000);
 if(m>0){e->drop=frames;return;}
 static int16_t zero[2*960];while(frames>0&&!quit){snd_pcm_sframes_t n=snd_pcm_writei(e->pcm,zero,frames>960?960:frames);if(n==-EAGAIN){usleep(5000);continue;}if(n<0){if(snd_pcm_recover(e->pcm,n,1)<0)return;continue;}frames-=n;}}
static int emit_frame(struct engine *e,AVFrame *f){struct state s;if(!current(e,&s))return -1;if(!e->pcm){int r=snd_pcm_open(&e->pcm,"xc_native",SND_PCM_STREAM_PLAYBACK,SND_PCM_NONBLOCK);/* xc_native lives in /etc/asound.conf, which other plugins sometimes overwrite: then go to the HDMI device directly */if(r<0){fprintf(stderr,"ALSA open xc_native: %s, using plughw:0,2\n",snd_strerror(r));r=snd_pcm_open(&e->pcm,"plughw:0,2",SND_PCM_STREAM_PLAYBACK,SND_PCM_NONBLOCK);}if(r<0){fprintf(stderr,"ALSA open: %s\n",snd_strerror(r));e->pcm=NULL;return -1;}r=snd_pcm_set_params(e->pcm,SND_PCM_FORMAT_S16_LE,SND_PCM_ACCESS_RW_INTERLEAVED,2,48000,1,80000);if(r<0){fprintf(stderr,"ALSA params: %s\n",snd_strerror(r));return -1;}}
 if(!e->swr||e->rate!=f->sample_rate||e->format!=f->format||e->channels!=f->ch_layout.nb_channels){swr_free(&e->swr);AVChannelLayout stereo=AV_CHANNEL_LAYOUT_STEREO;if(swr_alloc_set_opts2(&e->swr,&stereo,AV_SAMPLE_FMT_S16,48000,&f->ch_layout,f->format,f->sample_rate,0,NULL)<0||swr_init(e->swr)<0)return -1;e->rate=f->sample_rate;e->format=f->format;e->channels=f->ch_layout.nb_channels;}
 int capacity=av_rescale_rnd(swr_get_delay(e->swr,f->sample_rate)+f->nb_samples,48000,f->sample_rate,AV_ROUND_UP);if(capacity<1||capacity>262144)return -1;int16_t *buf=av_malloc_array(capacity*2,sizeof(int16_t));if(!buf)return -1;uint8_t *out=(uint8_t*)buf;int count=swr_convert(e->swr,&out,capacity,(const uint8_t**)f->extended_data,f->nb_samples);if(count<0){av_free(buf);return -1;}
 int64_t pts=f->best_effort_timestamp;if(pts==AV_NOPTS_VALUE)pts=f->pts;if(pts==AV_NOPTS_VALUE)pts=e->nextpts;if(pts==AV_NOPTS_VALUE){av_free(buf);return 0;}e->nextpts=pts+(int64_t)count*90000/48000;
 /* Enigma2 sends its 0..100 volume as 63..0 "dB" (63 - vol*63/100). Taken literally that is
    -31.5 dB at 50%, far too quiet; use a loudness curve instead: gain = level^2
    (40*log10: 50% -12 dB, 25% -24 dB, 10% -40 dB), same as xc-volume-bridge. */
 double gl=s.mute||s.left>=63?0:pow((63.0-s.left)/63.0,2.0),gr=s.mute||s.right>=63?0:pow((63.0-s.right)/63.0,2.0);for(int i=0;i<count;i++){int16_t a=buf[2*i],b=buf[2*i+1];if(s.channel==1)b=a;else if(s.channel==2)a=b;else if(s.channel==3)a=b=(int16_t)(((int)a+b)/2);else if(s.channel==4){int16_t t=a;a=b;b=t;}buf[2*i]=(int16_t)(a*gl);buf[2*i+1]=(int16_t)(b*gr);}
 int offset=0;while(offset<count&&!quit){if(!current(e,&s)){av_free(buf);return -1;}if(s.play==2){if(!e->paused){snd_pcm_pause(e->pcm,1);e->paused=1;}usleep(10000);continue;}if(e->paused){snd_pcm_pause(e->pcm,0);e->paused=0;}if(e->drop){int k=e->drop<count-offset?e->drop:count-offset;e->drop-=k;offset+=k;continue;}snd_pcm_sframes_t n=snd_pcm_writei(e->pcm,buf+offset*2,count-offset);if(n==-EAGAIN){usleep(5000);continue;}if(n<0){if(snd_pcm_recover(e->pcm,n,1)<0){av_free(buf);return -1;}continue;}offset+=n;snd_pcm_sframes_t delay=0;snd_pcm_delay(e->pcm,&delay);int64_t heard=pts+((int64_t)offset-delay)*90000/48000;char value[96];snprintf(value,sizeof(value),"0x%08x",(uint32_t)heard);if(!e->started){char event[128];snprintf(event,sizeof(event),"AUDIO_START:%s",value);if(syswrite("/sys/class/tsync/event",event)<0){av_free(buf);return -1;}if(syswrite("/sys/class/tsync/mode",e->fileclock&&!e->audiomaster?"0":"1")<0){av_free(buf);return -1;}
 e->started=1;e->t_next=now_ms()+2500;fprintf(stderr,"XC audio PCM running pts=%s clock=%s\n",value,e->fileclock&&!e->audiomaster?"XC-video":"audio");}syswrite("/sys/class/tsync/pts_audio",value);file_clock_guard(e);align_check(e,heard);}
 av_free(buf);return quit?-1:0;}
static int decode(struct engine *e,const uint8_t *data,int size){while(size>0){uint8_t *packet=NULL;int length=0;int used=av_parser_parse2(e->parser,e->dec,&packet,&length,data,size,e->pts,e->pts,AV_NOPTS_VALUE);e->pts=AV_NOPTS_VALUE;if(used<0)return -1;if(!used&&!length)break;data+=used;size-=used;if(!length)continue;av_packet_unref(e->packet);if(av_new_packet(e->packet,length)<0)return -1;memcpy(e->packet->data,packet,length);e->packet->pts=e->parser->pts;e->packet->dts=e->parser->dts;int ret=avcodec_send_packet(e->dec,e->packet);if(ret<0&&ret!=AVERROR(EAGAIN))continue;while(avcodec_receive_frame(e->dec,e->frame)>=0){if(emit_frame(e,e->frame)<0)return -1;av_frame_unref(e->frame);}}return 0;}
static int ts(struct engine *e,uint8_t *p){if(p[0]!=0x47||(p[1]&0x80))return 0;int pid=((p[1]&31)<<8)|p[2];if(pid!=e->initial.pid||!(p[3]&0x10)||(p[3]&0xc0))return 0;int cc=p[3]&15;if(e->cc_valid&&cc==e->cc)return 0;if(e->cc_valid&&cc!=((e->cc+1)&15)){avcodec_flush_buffers(e->dec);e->pts=e->nextpts=AV_NOPTS_VALUE;e->need=0;}e->cc=cc;e->cc_valid=1;int at=4;if(p[3]&0x20)at+=1+p[4];if(at>=188)return 0;if(p[1]&0x40){e->hn=0;e->need=9;}while(e->need&&at<188){int n=e->need-e->hn;if(n>188-at)n=188-at;if(n<1||e->hn+n>(int)sizeof(e->header))return -1;memcpy(e->header+e->hn,p+at,n);e->hn+=n;at+=n;if(e->hn==9){if(e->header[0]||e->header[1]||e->header[2]!=1)return -1;e->need=9+e->header[8];}if(e->hn==e->need){if((e->header[7]&0x80)&&e->hn>=14){uint8_t *b=e->header+9;e->pts=((int64_t)(b[0]&14)<<29)|((int64_t)b[1]<<22)|((b[2]&254)<<14)|(b[3]<<7)|(b[4]>>1);}e->need=0;}}
 return at<188&&!e->need?decode(e,p+at,188-at):0;}
int main(void){signal(SIGTERM,stop);signal(SIGINT,stop);hiu_lead();setvbuf(stderr,NULL,_IOLBF,0);av_log_set_level(AV_LOG_WARNING);struct engine e={.fd=-1};struct state s;uint8_t buffer[188*128+AV_INPUT_BUFFER_PADDING_SIZE];int fill=0;
 while(!quit){if(state_read(&s)||s.pid<0||s.play==0||s.source!=0){if(e.dec)engine_close(&e);fill=0;usleep(20000);continue;}if(e.dec&&s.gen!=e.initial.gen){engine_close(&e);fill=0;}if(!e.dec){if(engine_open(&e,&s)<0){perror("XC audio open");engine_close(&e);usleep(200000);continue;}}
 file_clock_guard(&e);if(s.play==2){usleep(10000);continue;}struct pollfd fd={e.fd,POLLIN,0};if(poll(&fd,1,20)<=0)continue;int n=read(e.fd,buffer+fill,sizeof(buffer)-AV_INPUT_BUFFER_PADDING_SIZE-fill);if(n<=0){if(n==0||errno!=EAGAIN){engine_close(&e);fill=0;}continue;}fill+=n;memset(buffer+fill,0,AV_INPUT_BUFFER_PADDING_SIZE);int off=0,failed=0;while(fill-off>=188){if(buffer[off]!=0x47){off++;continue;}if(ts(&e,buffer+off)<0){failed=1;break;}off+=188;}if(failed){engine_close(&e);fill=0;}else{memmove(buffer,buffer+off,fill-off);fill-=off;}}
 engine_close(&e);return 0;}
