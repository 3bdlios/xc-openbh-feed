from Components.ActionMap import ActionMap
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from enigma import eDVBDB
from . import core,runtime

class DirectScreen(Screen):
    skin='''<screen position="center,center" size="1100,570" title="XC Abertis Direct" backgroundColor="#101c2c">
    <eLabel position="0,0" size="8,570" backgroundColor="#18c6cc" />
    <eLabel text="XC  /  ABERTIS" position="40,24" size="1000,50" font="Regular;36" foregroundColor="#18c6cc" backgroundColor="#101c2c" />
    <eLabel text="HISPASAT 30W · DIRECT" position="40,80" size="1000,35" font="Regular;22" foregroundColor="#a8b9cc" backgroundColor="#101c2c" />
    <widget name="status" position="40,140" size="1020,270" font="Regular;25" backgroundColor="#101c2c" />
    <eLabel text="MENU: تعطيل   |   INFO: التشخيص" position="40,423" size="1020,35" font="Regular;22" foregroundColor="#a8b9cc" backgroundColor="#101c2c" />
    <widget name="red" position="40,496" size="210,45" font="Regular;23" foregroundColor="#ff7272" backgroundColor="#101c2c" />
    <widget name="green" position="270,496" size="260,45" font="Regular;23" foregroundColor="#68ddb1" backgroundColor="#101c2c" />
    <widget name="yellow" position="550,496" size="250,45" font="Regular;23" foregroundColor="#f4ce72" backgroundColor="#101c2c" />
    <widget name="blue" position="820,496" size="240,45" font="Regular;23" foregroundColor="#79b8ff" backgroundColor="#101c2c" />
    </screen>'''
    def __init__(self,session):
        Screen.__init__(self,session)
        self['status']=Label('مسار أبرتيس المباشر — نسخة تجربة\nأداة EX الأصلية لاستخراج البث، والصورة والصوت بمشغّل XC.\nلا يحتاج Astra أو F1/F5، ولا يبدّل مشغّل النظام.\nيتطلب تفعيل هسباسات في التيونر وملف مفاتيح موجود.\nالأزرق: تحديث المفاتيح، الأصفر: مسار الملف.\nعطّل إضافة XCAbertis القديمة أولاً إن كانت مفعّلة.')
        self['yellow']=Label('مسار المفاتيح')
        self['red']=Label('إغلاق');self['green']=Label('تجهيز القائمة والتفعيل');self['blue']=Label('تحديث المفاتيح')
        self['actions']=ActionMap(['ColorActions','OkCancelActions','MenuActions','InfobarEPGActions'],{'red':self.close,'cancel':self.close,'green':self.enable,'menu':self.disable,'yellow':self.keyfile,'blue':self.update_keys,'showEventInfo':self.diagnostics,'ok':self.diagnostics},-1)
    def update_keys(self):
        if getattr(self,'key_job',None):return
        import queue,threading
        from enigma import eTimer
        from . import keys
        self.key_job=queue.Queue()
        result=self.key_job
        def work():
            try:result.put(keys.update())
            except Exception as exc:result.put(str(exc))
        self.key_timer=eTimer();self.key_timer.callback.append(self.poll_keys)
        self.onClose.append(self.key_timer.stop)
        self['status'].setText('جارٍ تحديث المفاتيح من المصادر المضبوطة…\nيمكنك إغلاق النافذة؛ يستمر التحديث في الخلفية.')
        threading.Thread(target=work,daemon=True).start();self.key_timer.start(200)
    def poll_keys(self):
        if self.key_job.empty():return
        self.key_timer.stop();self['status'].setText(self.key_job.get());self.key_job=None
    def enable(self):
        try:
            if runtime.manager is None:runtime.manager=runtime.Manager(self.session)
            core.check_tool();core.find_keyfile()
            runtime.manager.start()
            db=eDVBDB.getInstance();db.saveServicelist();core.install_bouquet();db.reloadBouquets()
            core.CONFIG.mkdir(parents=True,exist_ok=True);(core.CONFIG/'enabled').touch()
            self['status'].setText('تم تجهيز باقة XC Abertis Direct.\nاختر قناة من الباقة الجديدة.\nهذه نسخة أولية؛ يحتاج تشغيل القنوات لتأكيد استقبال البث.')
        except Exception as exc:
            runtime.log(str(exc));self['status'].setText('لم يكتمل التجهيز:\n'+str(exc))
    def keyfile(self):
        from Screens.InputBox import InputBox
        self.session.openWithCallback(self.set_keyfile,InputBox,title='مسار ملف المفاتيح الموجود (SoftCam.Key)',text='/etc/tuxbox/config/SoftCam.Key')
    def set_keyfile(self,path):
        if not path:return
        from pathlib import Path
        if not Path(path).is_absolute() or not Path(path).is_file():
            self['status'].setText('المسار غير موجود؛ لم تتغير الإعدادات.')
            return
        core.CONFIG.mkdir(parents=True,exist_ok=True)
        core.atomic(core.CONFIG/'keyfile',path+'\n')
        self['status'].setText('تم اختيار مسار ملف المفاتيح. اضغط الأخضر للتفعيل.')
    def disable(self):
        try:
            if runtime.manager:runtime.manager.stop()
            else:(core.CONFIG/'enabled').unlink(missing_ok=True)
            self['status'].setText('تم التعطيل. القائمة تبقى محفوظة. يمكن إعادة التفعيل بالأخضر.')
        except Exception as exc:self['status'].setText(str(exc))
    def diagnostics(self):
        try:text=open('/tmp/xc-abertis-direct.log').read()[-3000:]
        except OSError:text='No playback attempt logged.'
        self.session.open(MessageBox,text,type=MessageBox.TYPE_INFO)

def main(session,**kwargs):session.open(DirectScreen)
def Plugins(**kwargs):
    return [PluginDescriptor(name='XC Abertis Direct TEST',description='Direct EX extraction to XC native playback',where=PluginDescriptor.WHERE_PLUGINMENU,icon='plugin.png',fnc=main),PluginDescriptor(name='XC Abertis Direct',where=PluginDescriptor.WHERE_SESSIONSTART,fnc=runtime.session_start)]
