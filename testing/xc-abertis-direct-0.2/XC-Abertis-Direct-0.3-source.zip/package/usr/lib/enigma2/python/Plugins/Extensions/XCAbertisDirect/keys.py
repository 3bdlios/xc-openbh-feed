"""User-configured Abertis source synchronization; based on EXAbertis discovery."""
import os, re, time, shutil, tempfile
from pathlib import Path
from urllib.request import Request, urlopen
from . import core
OSCAM = ("/etc/tuxbox/config/oscam.server", "/etc/tuxbox/config/oscam-emu/oscam.server", "/etc/tuxbox/config/oscam/oscam.server")
EXTRA = "/etc/enigmax/abertis-key-urls"
def urls():
    out = []
    for path in OSCAM:
        try:
            for line in open(path, encoding="utf-8", errors="replace"):
                m = re.match(r"\s*device\s*=\s*(https?://\S+)", line)
                if m and m.group(1) not in out:
                    out.append(m.group(1))
        except OSError:
            pass
    try:
        for line in open(EXTRA, encoding="utf-8", errors="replace"):
            line = line.strip()
            if line.startswith(("http://", "https://")) and line not in out:
                out.append(line)
    except OSError:
        pass
    return out



def update():
    sources=urls()
    local=core.CONFIG/'key-urls'
    if local.is_file():
        for line in local.read_text().splitlines():
            line=line.strip()
            if line.startswith(('https://','http://')) and line not in sources:sources.append(line)
    if not sources:raise RuntimeError('لا توجد مصادر مضبوطة في oscam.server أو ملف key-urls.')
    records={}
    for url in sources:
        try:
            with urlopen(Request(url,headers={'User-Agent':'XC-Abertis'}),timeout=20) as response:
                data=response.read(2097153)
            if len(data)>2097152:continue
            for line in data.decode('utf-8','replace').splitlines():
                if 'ABERTIS' not in line.upper():continue
                match=re.match(r'^\s*F\s+([0-9a-fA-F]{8})\s+([0-9a-fA-F]{2})\s+([0-9a-fA-F]{16})(?:\s|$)',line)
                if match:records.setdefault((match[1].upper(),match[2].upper()),line.strip())
        except Exception:continue
    if not records:raise RuntimeError('لم تصل مفاتيح أبرتيس صالحة؛ لم يتغير الملف.')
    try:target=Path(core.find_keyfile())
    except RuntimeError:
        if (core.CONFIG/'keyfile').exists():raise
        target=Path('/etc/tuxbox/config/SoftCam.Key')
    old=target.read_text(errors='replace') if target.exists() else ''
    begin='; XC ABERTIS BEGIN';end='; XC ABERTIS END'
    kept=[];inside=False
    for line in old.splitlines():
        if line==begin:inside=True;continue
        if inside:
            if line==end:inside=False
            continue
        m=re.match(r'^\s*F\s+([0-9a-fA-F]{8})\s+([0-9a-fA-F]{2})\s+',line)
        if m and (m[1].upper(),m[2].upper()) in records:continue
        kept.append(line)
    if inside:raise RuntimeError('قسم تحديث سابق غير مكتمل؛ لم يتغير الملف.')
    core.CONFIG.mkdir(parents=True,exist_ok=True)
    backup=core.CONFIG/'backup'/time.strftime('%Y%m%d-%H%M%S')
    backup.mkdir(parents=True,exist_ok=True)
    if target.exists():shutil.copy2(target,backup/'SoftCam.Key')
    target.parent.mkdir(parents=True,exist_ok=True)
    text='\n'.join(kept+[begin]+list(records.values())+[end])+'\n'
    fd,tmp=tempfile.mkstemp(prefix='.xc-keys-',dir=str(target.parent))
    try:
        with os.fdopen(fd,'w') as f:f.write(text);f.flush();os.fsync(f.fileno())
        os.replace(tmp,target)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    core.atomic(core.CONFIG/'keyfile',str(target)+'\n')
    return 'تم تحديث %d سجل مفاتيح، وحفظ نسخة رجوع.'%len(records)
