#!/usr/bin/env python3
from pathlib import Path
import hashlib
import io
import subprocess
import tarfile
import tempfile
root=Path(__file__).resolve().parent
stage=root/'package';out=root/'output';out.mkdir(exist_ok=True)
package=out/'enigma2-plugin-extensions-xcabertisdirect_0.6-r1_cortexa55.ipk'
with tempfile.TemporaryDirectory() as temp:
    work=Path(temp);(work/'debian-binary').write_bytes(b'2.0\n')
    with tarfile.open(work/'control.tar.gz','w:gz') as tar:
        for path in sorted((stage/'CONTROL').iterdir()):tar.add(path,arcname='./'+path.name)
    with tarfile.open(work/'data.tar.gz','w:gz') as tar:
        for path in sorted((stage/'usr').rglob('*')):
            if '__pycache__' in path.parts or path.suffix=='.pyc':continue
            tar.add(path,arcname='./'+str(path.relative_to(stage)),recursive=False)
    package.unlink(missing_ok=True)
    subprocess.run(['ar','rc',str(package),'debian-binary','control.tar.gz','data.tar.gz'],cwd=work,check=True)
(package.with_suffix('.ipk.sha256')).write_text(hashlib.sha256(package.read_bytes()).hexdigest()+'  '+package.name+'\n')
print(package)
