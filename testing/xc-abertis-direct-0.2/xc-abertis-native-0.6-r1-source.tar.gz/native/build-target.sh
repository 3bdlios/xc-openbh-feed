#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
TASK_ROOT=$PWD
TASK_SYSROOT=${XC_SYSROOT:-$(realpath ../xc-system/standard-dvb/audio/test-sysroot)}
TASK_BINUTILS=${XC_BINUTILS:-$(realpath ../xc-system/standard-dvb/audio/cross-tools)}
TASK_GCCLIB=${XC_GCCLIB:-$TASK_SYSROOT/usr/lib/aarch64-oe-linux/16.2.0}
export TASK_SYSROOT TASK_BINUTILS TASK_GCCLIB
mkdir -p native/build/target-source native/build/target-build native/build/target-prefix
# Pristine public library source; no binary from an image is used.
tar -xzf vendor/libdvbcsa-source.tar.gz -C native/build/target-source
cat > native/build/cross-cc <<'CC'
#!/bin/bash
exec clang --target=aarch64-linux-gnu --sysroot="$TASK_SYSROOT" \
 -B "$TASK_BINUTILS" -B "$TASK_GCCLIB" \
 -L"$TASK_SYSROOT/usr/lib" -L"$TASK_SYSROOT/lib" -L"$TASK_GCCLIB" \
 -Wl,-rpath-link,"$TASK_SYSROOT/usr/lib" "$@"
CC
chmod 755 native/build/cross-cc
(
 cd native/build/target-source
 ./bootstrap
)
(
 cd native/build/target-build
 CC="$TASK_ROOT/native/build/cross-cc" AR=ar RANLIB=ranlib \
 ../target-source/configure --host=aarch64-linux-gnu --prefix="$TASK_ROOT/native/build/target-prefix" --disable-static
 make -j2
 make install
)
TASK_PLUGIN=$TASK_ROOT/package/usr/lib/enigma2/python/Plugins/Extensions/XCAbertisDirect
cp -L native/build/target-prefix/lib/libdvbcsa.so.1 "$TASK_PLUGIN/lib/libdvbcsa.so.1"
native/build/cross-cc -O2 -Wall -Wextra -Werror -Wno-misleading-indentation \
 -Inative/build/target-prefix/include native/xcab-engine.c \
 -Lnative/build/target-prefix/lib -ldvbcsa -Wl,-rpath,'$ORIGIN/../lib' \
 -o "$TASK_PLUGIN/bin/xcab-engine"
chmod 755 "$TASK_PLUGIN/bin/xcab-engine"
file "$TASK_PLUGIN/bin/xcab-engine" "$TASK_PLUGIN/lib/libdvbcsa.so.1"
