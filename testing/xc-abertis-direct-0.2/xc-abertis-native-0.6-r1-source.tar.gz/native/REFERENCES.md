# XC transport implementation references

The implementation was written for XC around public transport formats and
synthetic fixtures. Protocol compatibility is not a promise of RF reception.

- DVB T2-MI framing and BBFRAME payload: [ETSI TS 102 773 V1.4.1](https://www.etsi.org/deliver/etsi_ts/102700_102799/102773/01.04.01_60/ts_102773v010401p.pdf), clauses 5.1 and 5.2.
- BBHEADER, normal/high efficiency TS adaptation: [ETSI EN 302 755 V1.4.1](https://www.etsi.org/deliver/etsi_en/302700_302799/302755/01.04.01_60/en_302755v010401p.pdf), clause 5.
- Linux DVB input uses DMX_SET_PES_FILTER / DMX_OUT_TSDEMUX_TAP, declared by the kernel's public linux/dvb/dmx.h ABI.
- CSA operations use the public API of [libdvbcsa](https://github.com/oe-mirrors/libdvbcsa), with its GPL notices preserved.

Scope: aligned 188-byte outer TS, data piping and basic PES, inner PAT/PMT/SDT,
CSA key-file matching, TS payloads within NM/HEM T2-MI BBFRAMEs. ISSY and NPD
are rejected; general PLP discovery and split PES headers need further work.
The built-in catalog comes from factual tuning/program identifiers supplied
with the working reference image; no reference implementation is linked.
