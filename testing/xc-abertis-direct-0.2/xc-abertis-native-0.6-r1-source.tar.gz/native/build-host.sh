#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
TASK_ROOT=$PWD
mkdir -p native/build/host-source native/build/host-build vendor/host
tar -xzf vendor/libdvbcsa-source.tar.gz -C native/build/host-source
(cd native/build/host-source && ./bootstrap)
(cd native/build/host-build && ../host-source/configure --prefix="$TASK_ROOT/vendor/host" --disable-static && make -j2 && make install)
cc -O2 -g -Wall -Wextra -Werror -Wno-misleading-indentation -Ivendor/host/include \
 native/xcab-engine.c -Lvendor/host/lib -Wl,-rpath,'$ORIGIN/../../vendor/host/lib' -ldvbcsa \
 -o native/build/xcab-engine
python3 native/test_engine.py
python3 -m unittest discover -s . -p 'test*.py'
