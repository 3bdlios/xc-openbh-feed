/* SPDX-License-Identifier: GPL-2.0-or-later
 * Copyright (C) 2026 XC contributors.
 * Independent TS-in-TS / T2-MI receiver. XC original implementation.
 * Uses libdvbcsa's public API. See REFERENCES.md for wire-format specifications.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <ctype.h>
#include <dvbcsa/dvbcsa.h>

#define TS 188
#define MAX_KEY 1024
#define PROBE 32
#define CAP 32768
static volatile sig_atomic_t stopped;
static int wanted_pid=-1, wanted_program=0, list_mode=0, wanted_plp=-1;
static unsigned out_count, input_count, key_count;
static struct { unsigned char cw[8]; struct dvbcsa_key_s *key; } keys[MAX_KEY];
static int chosen=-2; /* -2 unknown, -1 clear */
static unsigned char probe[PROBE][TS];static int probe_n;
static const char *key_path=NULL;
static time_t key_mtime;
static time_t next_probe;
static unsigned sync_failures;
static int warned_bb_mode;
static unsigned crc32mpeg(const unsigned char *p,size_t n) {
 unsigned c=0xffffffffU;
 for(size_t i=0;i<n;i++){c^=(unsigned)p[i]<<24;for(int j=0;j<8;j++)c=c&0x80000000U?(c<<1)^0x04c11db7U:c<<1;}
 return c;
}
static unsigned u16(const unsigned char *p){return ((unsigned)p[0]<<8)|p[1];}
static void sigstop(int s){(void)s;stopped=1;}
static int offset(const unsigned char *p) {
 if(p[0]!=0x47 || (p[1]&0x80))return -1;
 int af=(p[3]>>4)&3;if(af!=1&&af!=3)return -1;
 int n=af==3?5+p[4]:4;return n<TS?n:-1;
}
static void load_keys(void) {
 for(unsigned i=0;i<key_count;i++)dvbcsa_key_free(keys[i].key);
 key_count=0;
 if(!key_path)return;
 FILE *f=fopen(key_path,"r");if(!f)return;
 char line[2048],kind[4],id[32],idx[32],cw[64];
 while(fgets(line,sizeof(line),f)&&key_count<MAX_KEY){
  if(sscanf(line,"%3s %31s %31s %63s",kind,id,idx,cw)!=4||strcmp(kind,"F")||strlen(cw)!=16)continue;
  unsigned char bytes[8];int valid=1;
  for(int i=0;i<8;i++){char b[3]={cw[2*i],cw[2*i+1],0};char *end;long x=strtol(b,&end,16);if(!isxdigit((unsigned char)b[0])||!isxdigit((unsigned char)b[1])||*end){valid=0;break;}bytes[i]=(unsigned char)x;}
  if(!valid)continue;
  unsigned j;for(j=0;j<key_count;j++)if(!memcmp(bytes,keys[j].cw,8))break;
  if(j<key_count)continue;
  memcpy(keys[key_count].cw,bytes,8);keys[key_count].key=dvbcsa_key_alloc();
  if(!keys[key_count].key)break;
  dvbcsa_key_set(bytes,keys[key_count].key);key_count++;
 }
 fclose(f);struct stat st;if(!stat(key_path,&st))key_mtime=st.st_mtime;
 fprintf(stderr,"XC key file loaded: %u distinct records\n",key_count);
}
/* PSI and T2MI use independently bounded reassembly buffers. */
struct section {unsigned char data[CAP];size_t used,need;int cc;};
struct program {unsigned sid,pmt,pcr,type;char name[160],streams[512];int ready;};
struct mux {struct section *psi[8192];struct program progs[256];unsigned n;int t2pid;struct section t2;};
static struct mux muxes[2];
static unsigned char rawbuf[CAP];static size_t rawused;
static unsigned char bbpart[188];static size_t bbused;static int bbmode=-1;
static void final_ts(struct mux *,const unsigned char *,int);
static void emit(const unsigned char *p) { if(!list_mode){if(fwrite(p,1,TS,stdout)!=TS)stopped=1;out_count++;} }
static void names(struct mux *m,const unsigned char *s,size_t n){
 if(n<15)return;size_t pos=11;
 while(pos+5<=n-4){unsigned sid=u16(s+pos);size_t end=pos+5+(((s[pos+3]&15)<<8)|s[pos+4]);
  if(end>n-4)break;
  for(size_t j=pos+5;j+2<=end;){size_t len=s[j+1];if(j+2+len>end)break;
   if(s[j]==0x48&&len>=3){size_t k=j+4+s[j+3];if(k<j+2+len){size_t nl=s[k++];if(k+nl<=j+2+len){
    for(unsigned x=0;x<m->n;x++)if(m->progs[x].sid==sid){struct program *p=&m->progs[x];p->type=s[j+2];if(nl>=sizeof(p->name))nl=sizeof(p->name)-1;
     for(size_t q=0;q<nl;q++)p->name[q]=(s[k+q]>=32&&s[k+q]!='"')?s[k+q]:' ';p->name[nl]=0;
    }
   }}}
   j+=2+len;
  }pos=end;
 }
}
static void psi_done(struct mux *m,unsigned pid,const unsigned char *s,size_t n){
 if(n<8||crc32mpeg(s,n)!=0||!(s[5]&1))return;
 if(pid==0&&s[0]==0){
  for(size_t i=8;i+4<=n-4;i+=4){unsigned sid=u16(s+i),pmt=((s[i+2]&31)<<8)|s[i+3];if(!sid)continue;
   unsigned j;for(j=0;j<m->n;j++)if(m->progs[j].sid==sid)break;
   if(j==m->n&&m->n<256){memset(&m->progs[j],0,sizeof(m->progs[j]));m->progs[j].sid=sid;m->n++;}
   if(j<m->n)m->progs[j].pmt=pmt;
  }
 }else if(pid==17&&s[0]==0x42)names(m,s,n);
 else if(s[0]==2&&n>=16){
  for(unsigned q=0;q<m->n;q++){struct program *p=&m->progs[q];if(p->pmt!=pid||p->sid!=u16(s+3))continue;
   p->pcr=((s[8]&31)<<8)|s[9];p->streams[0]=0;
   size_t i=12+(((s[10]&15)<<8)|s[11]);int video=0;
   while(i+5<=n-4){unsigned type=s[i],epid=((s[i+1]&31)<<8)|s[i+2];size_t len=((s[i+3]&15)<<8)|s[i+4];if(i+5+len>n-4)break;
    char part[48];snprintf(part,sizeof(part)," %u/0x%02X",epid,type);size_t used=strlen(p->streams);if(used+strlen(part)<sizeof(p->streams))strcat(p->streams,part);
    if(type==1||type==2||type==0x1b||type==0x24){video=1;if(!p->type)p->type=type==0x24?31:type==0x1b?25:1;}
    for(size_t d=i+5;d+2<=i+5+len;){size_t l=s[d+1];if(d+2+l>i+5+len)break;if(s[d]==0x7f&&l>=1&&s[d+2]==0x11)m->t2pid=(int)epid;d+=2+l;}
    i+=5+len;
   }
   if(!video&&!p->type)p->type=2;p->ready=1;
  }
 }
}
static unsigned char crc8(const unsigned char *p,size_t n){unsigned char x=0;for(size_t i=0;i<n;i++){x^=p[i];for(int b=0;b<8;b++)x=x&128?(unsigned char)((x<<1)^0xd5):(unsigned char)(x<<1);}return x;}
static void bb_data(const unsigned char *b,size_t n){
 if(n<10){bbused=0;return;}
 unsigned mode=crc8(b,9)^b[9];if(mode>1){bbused=0;return;}
 if((b[0]>>6)!=3 || (b[0]&12)){if(!warned_bb_mode++)fprintf(stderr,"XC unsupported BBFRAME: ISSY/NPD or non-TS\n");bbused=0;return;}
 size_t bytes=u16(b+4)/8,first=u16(b+7)/8;unsigned bits=u16(b+4);
 if((bits&7)||bytes>n-10||(u16(b+7)!=65535&&(u16(b+7)&7))){bbused=0;return;}
 if(!mode&&(u16(b+2)!=1504||b[6]!=0x47)){bbused=0;return;}
 const unsigned char *data=b+10;size_t packet=mode?187:188;
 if(bbmode!=(int)mode){bbused=0;bbmode=(int)mode;}
 size_t at=0;
 if(bbused&&u16(b+7)!=65535&&first!=packet-bbused)bbused=0;
 if(bbused){size_t take=packet-bbused;if(take>bytes)take=bytes;memcpy(bbpart+bbused,data,take);bbused+=take;at=take;
  if(bbused==packet){unsigned char ts[188];ts[0]=0x47;memcpy(ts+1,bbpart+(mode?0:1),187);final_ts(&muxes[1],ts,1);bbused=0;}
 }
 if(!bbused&&at==0){if(u16(b+7)==65535||first>bytes)return;at=first;}
 while(at<bytes){size_t take=packet-bbused;if(take>bytes-at)take=bytes-at;memcpy(bbpart+bbused,data+at,take);bbused+=take;at+=take;
  if(bbused==packet){unsigned char ts[188];ts[0]=0x47;memcpy(ts+1,bbpart+(mode?0:1),187);final_ts(&muxes[1],ts,1);bbused=0;}
 }
}
static void t2_done(const unsigned char *s,size_t n){
 if(n<10||crc32mpeg(s,n)!=0){bbused=0;return;}
 if(n<23||s[0]!=0)return;
 unsigned plp=s[7];if(wanted_plp<0)wanted_plp=(int)plp;if((unsigned)wanted_plp!=plp)return;
 bb_data(s+9,n-13);
}
static void section_bytes(struct section *a,const unsigned char *p,size_t n,struct mux *m,unsigned pid,int is_t2){
 while(n){
  if(a->used==0&&*p==255)return;
  size_t header=is_t2?6:3;
  size_t want=a->need?a->need:header;
  size_t add=want-a->used;if(add>n)add=n;if(a->used+add>CAP){a->used=a->need=0;return;}
  memcpy(a->data+a->used,p,add);a->used+=add;p+=add;n-=add;
  if(!a->need&&a->used==header){a->need=is_t2?10+(u16(a->data+4)+7)/8:3U+(((a->data[1]&15)<<8)|a->data[2]);if(a->need<header||a->need>CAP){a->used=a->need=0;return;}}
  if(a->need&&a->used==a->need){if(is_t2)t2_done(a->data,a->used);else psi_done(m,pid,a->data,a->used);a->used=a->need=0;}
 }
}
static void section_packet(struct section *a,const unsigned char *p,struct mux *m,unsigned pid,int t2){
 int pos=offset(p);if(pos<0)return;int cc=p[3]&15;
 if(a->cc>=0&&cc==a->cc)return;
 if(a->cc>=0&&cc!=((a->cc+1)&15)){a->used=a->need=0;if(t2)bbused=0;}
 a->cc=cc;const unsigned char *payload=p+pos;size_t size=188-pos;
 if(p[1]&64){unsigned pointer=payload[0];if(pointer+1>size){a->used=a->need=0;return;}
  if(a->used)section_bytes(a,payload+1,pointer,m,pid,t2);a->used=a->need=0;payload+=1+pointer;size-=1+pointer;
 }else if(!a->used)return;
 section_bytes(a,payload,size,m,pid,t2);
}
static void final_ts(struct mux *m,const unsigned char *p,int inner){
 unsigned pid=((p[1]&31)<<8)|p[2];int psi=pid==0||pid==17;
 for(unsigned i=0;i<m->n;i++)if(m->progs[i].pmt==pid)psi=1;
 if(psi){if(!m->psi[pid]){m->psi[pid]=calloc(1,sizeof(struct section));if(!m->psi[pid]){stopped=1;return;}m->psi[pid]->cc=-1;}section_packet(m->psi[pid],p,m,pid,0);}
 if(!inner&&m->t2pid>=0){if(pid==(unsigned)m->t2pid)section_packet(&m->t2,p,m,pid,1);return;}
 if(!inner&&m->n==0)return;
 if(wanted_program){int ready=0;for(unsigned i=0;i<m->n;i++)if(m->progs[i].sid==(unsigned)wanted_program&&m->progs[i].ready)ready=1;if(!ready)return;}
 emit(p);
}
static int sync_index(const unsigned char *b,size_t n,int count){
 if(n<(size_t)count*TS)return -1;
 for(size_t i=0;i+(size_t)(count-1)*TS<n;i++){int j;for(j=0;j<count;j++)if(b[i+j*TS]!=0x47)break;if(j==count)return (int)i;}
 return -1;
}
static void raw_push(const unsigned char *b,size_t n){
 if(n+rawused>CAP){rawused=0;}memcpy(rawbuf+rawused,b,n);rawused+=n;
 while(rawused>=3*TS){int start=sync_index(rawbuf,rawused,3);if(start<0){sync_failures++;if(sync_failures>100){chosen=-2;probe_n=0;bbused=0;sync_failures=0;rawused=0;return;}memmove(rawbuf,rawbuf+rawused-2*TS,2*TS);rawused=2*TS;return;}
  if(start){memmove(rawbuf,rawbuf+start,rawused-start);rawused-=start;}
  sync_failures=0;final_ts(&muxes[0],rawbuf,0);memmove(rawbuf,rawbuf+TS,rawused-TS);rawused-=TS;
 }
}
static size_t payload(unsigned char *out,const unsigned char *packet,int key){
 unsigned char p[TS];memcpy(p,packet,TS);int off=offset(p);if(off<0)return 0;
 if((p[3]&0xc0)&&key>=0)dvbcsa_decrypt(keys[key].key,p+off,TS-off);
 if((p[3]&0xc0)&&key==-1)return 0;
 /* MPEG PES wrapper, when present; raw data-piping needs no wrapper removal. */
 if((p[1]&64)&&TS-off>=6&&p[off]==0&&p[off+1]==0&&p[off+2]==1){
  int sid=p[off+3];if(sid==0xbc||sid==0xbe||sid==0xbf)off+=6;
  else if(TS-off>=9)off+=9+p[off+8];
 }
 if(off>=TS)return 0;memcpy(out,p+off,TS-off);return TS-off;
}
static int choose_key(void){
 unsigned char b[PROBE*TS];
 for(int k=-1;k<(int)key_count;k++){size_t n=0;for(int i=0;i<probe_n;i++)n+=payload(b+n,probe[i],k);
  if(sync_index(b,n,6)>=0){chosen=k;fprintf(stderr,"XC transport synchronized (%s)\n",k<0?"clear feed":"key matched");return 1;}
 }return 0;
}
static void packet(const unsigned char *p){
 if(p[0]!=0x47||(((p[1]&31)<<8)|p[2])!=wanted_pid)return;input_count++;
 if(chosen==-2){if(time(NULL)<next_probe)return;memcpy(probe[probe_n++],p,TS);if(probe_n<PROBE)return;
  if(!choose_key()){probe_n=0;next_probe=time(NULL)+1;return;}
  for(int i=0;i<probe_n;i++){unsigned char b[TS];size_t n=payload(b,probe[i],chosen);raw_push(b,n);}probe_n=0;
 }else{unsigned char b[TS];size_t n=payload(b,p,chosen);raw_push(b,n);}
}
static void json_string(const char *value) {
 putchar('"');
 for(const unsigned char *s=(const unsigned char *)value;*s;s++) {
  if(*s=='"'||*s=='\\') {putchar('\\');putchar(*s);}
  else if(*s<32||*s>=128)printf("\\u%04x",*s);
  else putchar(*s);
 }
 putchar('"');
}
static void print_list(void){
 struct mux *m=muxes[0].t2pid>=0?&muxes[1]:&muxes[0];
 for(unsigned i=0;i<m->n;i++){
  struct program *p=&m->progs[i];if(!p->ready)continue;
  printf("{\"program\":%u,\"pmt\":%u,\"service_type\":%u,\"name\":",p->sid,p->pmt,p->type);
  json_string(p->name);printf(",\"streams\":");json_string(p->streams);puts("}");
 }
}
#ifndef XC_TEST
int main(int argc,char **argv){
 int fd=-1,seconds=0;const char *file=NULL;
 for(int i=1;i<argc;i++){
  if(!strcmp(argv[i],"--list")){list_mode=1;continue;}
  if(!strcmp(argv[i],"--help")){puts("XC engine 0.1: --pid N --fd N|--file PATH [--program N] [--keyfile PATH] [--list --seconds N] [--plp N]");return 0;}
  if(i+1>=argc){fprintf(stderr,"Missing option value\n");return 2;}
  const char *a=argv[i++],*v=argv[i];char *end=NULL;long number=strtol(v,&end,10);
  if(!strcmp(a,"--keyfile"))key_path=v;
  else if(!strcmp(a,"--file"))file=v;
  else {if(*end||number<0||number>65535){fprintf(stderr,"Invalid argument\n");return 2;}
   if(!strcmp(a,"--pid"))wanted_pid=number;else if(!strcmp(a,"--program"))wanted_program=number;else if(!strcmp(a,"--fd"))fd=number;
   else if(!strcmp(a,"--seconds"))seconds=number;else if(!strcmp(a,"--plp"))wanted_plp=number;else {fprintf(stderr,"Unknown option\n");return 2;}
  }
 }
 if(wanted_pid<0||wanted_pid>8191){fprintf(stderr,"Valid --pid required\n");return 2;}
 if(file)fd=open(file,O_RDONLY);if(fd<0){perror("input");return 2;}
 signal(SIGTERM,sigstop);signal(SIGINT,sigstop);signal(SIGPIPE,sigstop);load_keys();setvbuf(stdout,NULL,_IOFBF,188*64);
 for(int i=0;i<2;i++){muxes[i].t2pid=-1;muxes[i].t2.cc=-1;}
 unsigned char buf[TS*256];size_t used=0;time_t start=time(NULL),last=start,last_check=start;
 while(!stopped){time_t now=time(NULL);if(seconds&&now-start>=seconds)break;if(now-last>15){fprintf(stderr,"XC input timed out\n");break;}
  if(now-last_check>=2){last_check=now;struct stat st;if(key_path&&!stat(key_path,&st)&&st.st_mtime!=key_mtime){load_keys();chosen=-2;probe_n=0;rawused=0;}}
  struct pollfd wait={fd,POLLIN,0};int rc=poll(&wait,1,200);if(rc<0){if(errno==EINTR)continue;break;}if(!rc)continue;
  ssize_t got=read(fd,buf+used,sizeof(buf)-used);if(got<0){if(errno==EAGAIN||errno==EINTR)continue;break;}if(!got)break;last=now;used+=got;
  size_t at=0;while(used-at>=TS){if(buf[at]!=0x47){at++;continue;}packet(buf+at);at+=TS;}memmove(buf,buf+at,used-at);used-=at;
 }
 if(list_mode)print_list();fflush(stdout);fprintf(stderr,"XC finished: %u outer, %u output packets\n",input_count,out_count);
 for(unsigned i=0;i<key_count;i++)dvbcsa_key_free(keys[i].key);for(int m=0;m<2;m++)for(int p=0;p<8192;p++)free(muxes[m].psi[p]);
 if(file)close(fd);return chosen==-2?3:0;
}
#endif
