"""Synthetic protocol tests only: no broadcaster recordings or real keys."""
import ctypes
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
ENGINE=Path(os.environ.get('XC_ENGINE', ROOT/'native/build/xcab-engine'))
LIB=ctypes.CDLL(str(ROOT/'vendor/host/lib/libdvbcsa.so'))
LIB.dvbcsa_key_alloc.restype=ctypes.c_void_p
LIB.dvbcsa_key_free.argtypes=[ctypes.c_void_p]
LIB.dvbcsa_key_set.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
LIB.dvbcsa_encrypt.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint]
CW=bytes.fromhex('1234569cabcdef67') # generated test value, not a broadcast key


def crc32(data):
    value=0xffffffff
    for x in data:
        value ^= x<<24
        for _ in range(8):value=((value<<1)^(0x04c11db7 if value&0x80000000 else 0))&0xffffffff
    return value

def checked(data):return data+struct.pack('>I',crc32(data))

def psi(table,body):return checked(bytes([table,0xb0|((len(body)+4)>>8),(len(body)+4)&255])+body)

class Mux:
    def __init__(self):self.cc={}
    def wrap(self,pid,payload,start=False):
        cc=self.cc.get(pid,0);self.cc[pid]=(cc+1)%16
        if len(payload)>184:raise ValueError('payload')
        header=bytes([0x47,(pid>>8)|(0x40 if start else 0),pid&255,0x10|cc])
        return header+payload+bytes([255])*(184-len(payload))
    def section(self,pid,data):
        chunks=[];initial=True
        while data:
            n=183 if initial else 184
            chunks.append(self.wrap(pid,(b'\0' if initial else b'')+data[:n],initial))
            data=data[n:];initial=False
        return b''.join(chunks)

PAT=psi(0,b'\x00\x01\xc1\x00\x00'+struct.pack('>HH',42,0xe100))
PMT=psi(2,struct.pack('>HBBBHH',42,0xc1,0,0,0xe101,0xf000)+bytes.fromhex('1be101f000'))
SDT=psi(0x42,bytes.fromhex('0001c100000001ff')+struct.pack('>H',42)+bytes.fromhex('fc800c480a190004')+b'Test'+b'XX') # corrected below
name=b'Test Channel';desc=bytes([0x48,len(name)+3,25,0,len(name)])+name
SDT=psi(0x42,bytes.fromhex('0001c100000001ff')+struct.pack('>H',42)+bytes([0xfc,0x80,len(desc)])+desc)


def stream(cycles=24):
    mux=Mux();packets=[]
    for i in range(cycles):
        packets.extend([mux.section(0,PAT),mux.section(256,PMT),mux.section(17,SDT)])
        packets += [mux.wrap(257,bytes([i,j])+bytes((k+j)%256 for k in range(182))) for j in range(20)]
    return b''.join(packets)


def outer(data,encrypt=False,pes=False):
    packets=[];mux=Mux();key=LIB.dvbcsa_key_alloc();LIB.dvbcsa_key_set(ctypes.c_char_p(CW),key)
    while data:
        packet=bytearray(mux.wrap(8001,data[:184]));data=data[184:]
        if encrypt:
            packet[3]|=0x80
            ptr=(ctypes.c_ubyte*184).from_buffer(packet,4)
            LIB.dvbcsa_encrypt(key,ptr,184)
        packets.append(bytes(packet))
    LIB.dvbcsa_key_free(key)
    return b''.join(packets)


def crc8(data):
    n=0
    for byte in data:
        n^=byte
        for _ in range(8):n=((n<<1)^(0xd5 if n&128 else 0))&255
    return n

def t2mi(data,hem=False,broken=False):
    """Package the inner TS into split BBFRAME records, then a DVB T2-MI PID."""
    records=b''.join((b'' if hem else b'\x55')+data[i+1:i+188] for i in range(0,len(data),188))
    size=187 if hem else 188
    mux=Mux();out=[];at=0;counter=0
    outer_pmt=psi(2,struct.pack('>HBBBHH',42,0xc1,0,0,0xe201,0xf000)+bytes.fromhex('06e200f0037f0111'))
    while at<len(records):
        payload=records[at:at+997];first=(size-at%size)%size
        if first>=len(payload):first=65535
        header=bytes([0xf0,0])+struct.pack('>HHB H',0 if hem else 1504,len(payload)*8,0x47,first*8 if first!=65535 else first)
        header+=bytes([crc8(header)^(1 if hem else 0)])
        bb=bytes([counter%256,0,0x80])+header+payload
        mi=checked(bytes([0,counter%256,0,0])+struct.pack('>H',len(bb)*8)+bb)
        if broken:mi=mi[:-1]+bytes([mi[-1]^1])
        out += [mux.section(0,PAT),mux.section(256,outer_pmt),mux.section(512,mi)]
        at+=len(payload);counter+=1
    return b''.join(out)

class EngineTests(unittest.TestCase):
    def run_engine(self,data,extra=(),keys=None):
        with tempfile.TemporaryDirectory() as directory:
            d=Path(directory);(d/'input.ts').write_bytes(data)
            args=[str(ENGINE),'--file',str(d/'input.ts'),'--pid','8001',*extra]
            if keys is not None:
                (d/'test.key').write_text(keys);args+=['--keyfile',str(d/'test.key')]
            return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12)
    def assert_transport(self,result,original):
        self.assertEqual(result.returncode,0,result.stderr.decode())
        self.assertGreater(len(result.stdout),188*100)
        self.assertEqual(len(result.stdout)%188,0)
        allowed={original[i:i+188] for i in range(0,len(original),188)}
        for i in range(0,len(result.stdout),188):self.assertIn(result.stdout[i:i+188],allowed)
    def test_clear_ts_in_ts(self):
        data=stream();self.assert_transport(self.run_engine(outer(data),['--program','42']),data)
    def test_scrambled_ts_in_ts(self):
        data=stream();result=self.run_engine(outer(data,True),['--program','42'],f'F 00000001 00 {CW.hex()} ; SYNTHETIC\n')
        self.assert_transport(result,data)
    def test_no_matching_key_produces_no_video(self):
        result=self.run_engine(outer(stream(),True),['--program','42'],'F 00000001 00 0000000000000000\n')
        self.assertNotEqual(result.returncode,0);self.assertEqual(result.stdout,b'')
    def test_missing_program_produces_no_other_channel(self):
        result=self.run_engine(outer(stream()),['--program','99'])
        self.assertEqual(result.stdout,b'')
    def test_json_search(self):
        result=self.run_engine(outer(stream()),['--list'])
        items=[json.loads(s) for s in result.stdout.splitlines()]
        self.assertEqual(items[0]['name'],'Test Channel');self.assertEqual(items[0]['program'],42)
        self.assertEqual(items[0]['service_type'],25)
    def test_t2mi_normal_with_split_packets(self):
        data=stream();result=self.run_engine(outer(t2mi(data)),['--program','42'])
        self.assert_transport(result,data)
    def test_t2mi_high_efficiency_with_split_packets(self):
        data=stream();result=self.run_engine(outer(t2mi(data,hem=True)),['--program','42'])
        self.assert_transport(result,data)
    def test_t2mi_bad_crc_not_played(self):
        result=self.run_engine(outer(t2mi(stream(),broken=True)),['--program','42'])
        self.assertEqual(result.stdout,b'')
    def test_t2mi_lost_outer_packet_recovers_at_next_boundary(self):
        data=stream();packed=t2mi(data)
        packets=[packed[i:i+188] for i in range(0,len(packed),188)]
        index=next(i for i,p in enumerate(packets) if i>32 and ((p[1]&31)<<8|p[2])==512)
        del packets[index]
        self.assert_transport(self.run_engine(outer(b''.join(packets)),['--program','42']),data)
    def test_malformed_input_fails_cleanly(self):
        for data in (b'',b'\x47'*18800,b'\xff'*100000):
            result=self.run_engine(data,['--list'])
            self.assertIn(result.returncode,(0,3));self.assertEqual(result.stdout,b'')

if __name__=='__main__':unittest.main()
