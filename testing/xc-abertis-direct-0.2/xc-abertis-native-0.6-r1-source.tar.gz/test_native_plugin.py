import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent/'package/usr/lib/enigma2/python/Plugins/Extensions'))
from XCAbertisDirect import core,keys,xcab_list,scan,runtime
sys.path.insert(0,str(Path(__file__).parent/'native'))
from test_engine import Mux,PAT

SYNTHETIC='F 12345678 00 0011223344556677 ; ABERTIS\n'

class PluginTests(unittest.TestCase):
    def test_multistream_tuning_not_discarded(self):
        c=next(c for c in core.channels() if 'MIS/PLS' in c['transponder'])
        f=core.satellite_fields(c['transponder'])
        self.assertEqual((f['is_id'],f['pls_code'],f['pls_mode']),(0,0,1))
    def test_lamedb_preserves_services_and_is_idempotent(self):
        for text,records,add in (
            ('eDVB services /4/\ntransponders\nend\nservices\nKEEP ME\nend\n',xcab_list.seed_v4(),xcab_list.add_v4),
            ('eDVB services /5/\ns:KEEP ME\n',xcab_list.seed_v5(),xcab_list.add_v5)):
            changed,n=add(text,records);self.assertEqual(n,8);self.assertIn('KEEP ME',changed)
            self.assertEqual(add(changed,records),(changed,0))
    def test_unknown_lamedb_refused(self):
        with self.assertRaises(ValueError):xcab_list.add_v4('bad',xcab_list.seed_v4())
    def test_key_merge_preserves_unrelated(self):
        old='; personal comment\nF 87654321 00 8899aabbccddeeff ; OTHER\n'+SYNTHETIC
        entries=keys.parse(SYNTHETIC)
        result=keys.merge(old,entries)
        self.assertIn('personal comment',result);self.assertIn('8899aabbccddeeff',result)
        self.assertEqual(result.count('F 12345678'),1)
        self.assertEqual(keys.merge(result,entries),result)
    def test_broken_key_markers_refused(self):
        for text in (keys.BEGIN,keys.END,keys.END+'\n'+keys.BEGIN):
            with self.assertRaises(ValueError):keys.merge(text,keys.parse(SYNTHETIC))
    def test_update_backup_and_no_secret_in_status(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d);target=folder/'test.key';target.write_text('; preserve\n')
            with patch.object(core,'CONFIG',folder/'config'),patch.object(core,'find_keyfile',return_value=target),patch.object(keys,'urls',return_value=['https://example.invalid']),patch.object(keys,'_fetch',return_value=SYNTHETIC):
                message=keys.update();self.assertIn('Updated 1',message)
                self.assertNotIn('00112233',message)
                self.assertIn('; preserve',target.read_text())
                backups=list((folder/'config/backup').glob('*/SoftCam.Key'));self.assertEqual(len(backups),1)
                self.assertEqual(backups[0].read_text(),'; preserve\n')
                self.assertEqual(target.stat().st_mode&0o777,0o600)
                self.assertIn('Already up to date',keys.update())
    def test_ambiguous_keyfile_does_not_create_fallback(self):
        with tempfile.TemporaryDirectory() as d,patch.object(core,'CONFIG',Path(d)),patch.object(core,'find_keyfile',side_effect=RuntimeError('Ambiguous')),patch.object(keys,'_fetch') as fetch:
            with self.assertRaisesRegex(RuntimeError,'Ambiguous'):keys.update()
            fetch.assert_not_called()
    def test_failed_download_keeps_target(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d);target=folder/'test.key';target.write_text('untouched')
            with patch.object(core,'CONFIG',folder/'config'),patch.object(core,'find_keyfile',return_value=target),patch.object(keys,'urls',return_value=['https://example.invalid']),patch.object(keys,'_fetch',side_effect=OSError()):
                with self.assertRaises(RuntimeError):keys.update()
                self.assertEqual(target.read_text(),'untouched')
    def test_synthetic_psi_and_crc(self):
        parser=scan.Sections();packet=Mux().section(0,PAT)
        sections=parser.push(packet)
        self.assertEqual(sections,[PAT]);self.assertTrue(scan.valid_crc(PAT))
        self.assertEqual(parser.push(packet),[])
        self.assertFalse(scan.valid_crc(PAT[:-1]+bytes([PAT[-1]^1])))
    def test_catalog_accepts_only_json_records(self):
        record={'program':42,'service_type':25,'name':'Example'}
        parsed=scan.programs('debug\n'+json.dumps(record)+'\nnot json',core.channels()[0])
        self.assertEqual(len(parsed),1);self.assertEqual(parsed[0]['program'],42)
    def test_superseded_tuner_request_finishes_without_retuning(self):
        import queue
        m=runtime.Manager.__new__(runtime.Manager);m.status={};m.jobs=queue.Queue();m.pending=None;m.pending_play=None;m.lease=None
        calls=[];m.tune=lambda lease:calls.append(lease)
        a=runtime.Lease({});b=runtime.Lease({});m.jobs.put(a);m.jobs.put(b);m.tick()
        self.assertTrue(a.cancel.is_set());self.assertTrue(a.event.is_set());self.assertEqual(calls,[b])

if __name__=='__main__':unittest.main()
