# SPDX-License-Identifier: MIT
"""XC Abertis native channel manager."""
