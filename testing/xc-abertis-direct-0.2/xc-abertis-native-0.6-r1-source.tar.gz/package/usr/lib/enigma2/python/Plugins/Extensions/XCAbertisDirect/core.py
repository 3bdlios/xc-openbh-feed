"""XC Abertis catalog and native playback integration."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from urllib.parse import quote

HERE=Path(__file__).resolve().parent
PORT=9779
CONFIG=Path('/etc/xc-abertis-direct')
LOG=Path('/tmp/xc-abertis-direct.log')

def log(text):
    if LOG.exists() and LOG.stat().st_size>1024*1024:
        LOG.replace(str(LOG)+'.old')
    with LOG.open('a') as f:f.write(str(text)+'\n')

def channels():
    path=CONFIG/'channels.json'
    if not path.exists():path=HERE/'data/channels.json'
    return json.loads(path.read_text())

def merge_channels(found):
    data=channels();have={(c['ns'],c['tsid'],c['onid'],c['sid'],c['pid'],c['program']) for c in data}
    next_id=max([c['id'] for c in data]+[0])+1;added=0
    for channel in found:
        ident=tuple(channel[k] for k in ('ns','tsid','onid','sid','pid','program'))
        if ident in have:continue
        channel=dict(channel,id=next_id);next_id+=1;added+=1;data.append(channel);have.add(ident)
    if added:
        CONFIG.mkdir(parents=True,exist_ok=True)
        atomic(CONFIG/'channels.json',json.dumps(data,indent=2,ensure_ascii=False)+'\n')
    return added

def satellite_fields(line):
    if not line.startswith('s '):raise ValueError('Not a satellite transponder')
    main,*extensions=line[2:].split(',')
    raw=main.split(':')
    values=list(map(int,raw))
    if len(values)<7:raise ValueError('Incomplete satellite transponder')
    defaults=[0,1,0,2,-1,0,1,-1,4096]
    values += defaults[max(0,len(values)-7):]
    names=['frequency','symbol_rate','polarisation','fec','orbital_position','inversion',
           '_flags','system','modulation','rolloff','pilot','is_id','pls_code','pls_mode','t2mi_plp_id','t2mi_pid']
    result=dict(zip(names,values[:16]));result.pop('_flags')
    for extension in extensions:
        if extension.startswith('MIS/PLS:'):
            mis=list(map(int,extension.split(':')[1:]))
            if len(mis)!=3:raise ValueError('Invalid MIS/PLS parameters')
            result.update(zip(('is_id','pls_code','pls_mode'),mis))
    result['orbital_position']%=3600
    return result

def service_reference(channel):
    url='http://127.0.0.1:%d/xc-abertis/%d.ts' % (PORT,channel['id'])
    return '1:0:%X:%X:0:0:0:0:0:0:%s:%s' % (channel.get('service_type',1),channel['program'],quote(url,safe='/'),channel['name'].replace(':',' '))

def atomic(path,text):
    path=Path(path);fd,name=tempfile.mkstemp(prefix='.'+path.name,dir=str(path.parent))
    try:
        with os.fdopen(fd,'w') as f:f.write(text);f.flush();os.fsync(f.fileno())
        os.chmod(name,0o644);os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)

def install_bouquet(settings=Path('/etc/enigma2')):
    settings=Path(settings);CONFIG.mkdir(parents=True,exist_ok=True)
    backup=CONFIG/'backup';backup.mkdir(exist_ok=True);os.chmod(backup,0o700)
    from . import xcab_list
    for filename,seeds,add in (('lamedb',xcab_list.seed_v4(),xcab_list.add_v4),('lamedb5',xcab_list.seed_v5(),xcab_list.add_v5)):
        existing=settings/filename
        if not existing.exists():continue
        text,count=add(existing.read_text(),seeds)
        if count:
            saved=backup/(filename+'.original')
            if not saved.exists():shutil.copy2(existing,saved)
            atomic(existing,text)
    name='userbouquet.xc_abertis_direct.tv'
    text='#NAME XC Abertis (Hispasat 30W)\n'
    for c in channels():text+='#SERVICE '+service_reference(c)+'\n#DESCRIPTION '+c['name']+'\n'
    index=settings/'bouquets.tv'
    original=index.read_text() if index.exists() else '#NAME Bouquets (TV)\n'
    marker='#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "'+name+'" ORDER BY bouquet\n'
    for p in (index,settings/name):
        dest=backup/(p.name+'.original')
        if p.exists() and not dest.exists():shutil.copy2(p,dest);os.chmod(dest,0o600)
    atomic(settings/name,text)
    if '"'+name+'"' not in original:atomic(index,original.rstrip()+'\n'+marker)
    return len(channels())

class KeyfileNotFound(RuntimeError):
    pass

def find_keyfile():
    # Existing user key files only; no key download or automatic OSCam mutation.
    override=CONFIG/'keyfile'
    if override.exists():
        path=Path(override.read_text().strip())
        if path.is_file():return path
        raise RuntimeError('Configured keyfile does not exist')
    paths=set()
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if 'oscam' not in Path(os.readlink(proc/'exe')).name.lower():continue
            args=[s.decode() for s in (proc/'cmdline').read_bytes().split(b'\0') if s]
            for i,a in enumerate(args):
                directory=args[i+1] if a in ('-c','--config-dir') and i+1<len(args) else a[2:] if a.startswith('-c') and len(a)>2 else a.split('=',1)[1] if a.startswith('--config-dir=') else None
                if directory:
                    for spelling in ('SoftCam.Key','softcam.key'):
                        p=Path(directory)/spelling
                        if p.is_file():paths.add(p.resolve())
        except (OSError,UnicodeError):pass
    if not paths:
        for directory in ('/etc/tuxbox/config','/etc/tuxbox/config/oscam-emu','/etc/tuxbox/config/oscam','/etc/tuxbox/config/ncam','/etc/oscam','/etc/xc-abertis','/usr/keys','/var/keys'):
            for spelling in ('SoftCam.Key','softcam.key'):
                p=Path(directory)/spelling
                if p.is_file():paths.add(p.resolve())
    if not paths:raise KeyfileNotFound('No key file found. Use Update keys or select an existing file.')
    if len(paths)>1:
        content={p.read_bytes() for p in paths}
        if len(content)>1:raise RuntimeError('Multiple different keyfiles; select one in /etc/xc-abertis-direct/keyfile')
    return sorted(paths,key=str)[0]

def extractor_command(channel,input_fd,keyfile,list_only=False):
    if int(input_fd)<0:raise ValueError('Invalid input descriptor')
    cmd=[str(HERE/'bin/xcab-engine'),'--fd',str(input_fd),'--pid',str(channel['pid']),
         '--keyfile',str(keyfile)]
    if list_only:cmd+=['--list','--seconds','8']
    else:cmd+=['--program',str(channel['program'])]
    return cmd

def check_tool():
    r=subprocess.run(['/lib/ld-linux-aarch64.so.1','--library-path',str(HERE/'lib'),
                      '--list',str(HERE/'bin/xcab-engine')],capture_output=True,text=True,timeout=10)
    if r.returncode:raise RuntimeError('XC transport engine dependencies unavailable')
