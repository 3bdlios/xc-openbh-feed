# SPDX-License-Identifier: MIT
# Copyright (C) 2026 XC contributors.
"""Build missing tuning records from XC's catalog without replacing user data."""
import json
import re
from pathlib import Path

_ID = re.compile(r'^([0-9a-f]+):([0-9a-f]+):([0-9a-f]+)$', re.I)


def identity(value):
    match = _ID.fullmatch(value.strip())
    return tuple(int(part, 16) for part in match.groups()) if match else None


def transponders():
    from . import core
    unique = {}
    for channel in core.channels():
        ident = tuple(channel[field] for field in ('ns', 'tsid', 'onid'))
        unique[ident] = channel['transponder']
    return unique


def seed_v4():
    records = []
    for ident, tuning in transponders().items():
        # V4 puts MIS/PLS fields inline; V5 names the extension separately.
        main, *extensions = tuning.split(',')
        for extension in extensions:
            if extension.startswith('MIS/PLS:'):
                main += ':' + extension.split(':', 1)[1]
        records.append((ident, '%08x:%04x:%04x\n\t%s\n/' % (*ident, main)))
    return records


def seed_v5():
    return [(ident, 't:%08x:%04x:%04x,%s' % (*ident, tuning.replace('s ', 's:', 1)))
            for ident, tuning in transponders().items()]


def add_v4(text, records):
    # Work on the transponder section only. Services and unrelated text stay intact.
    match = re.search(r'(?m)^transponders\r?\n(?P<body>.*?)^end\s*$', text, re.S)
    if not match:
        raise ValueError('Unrecognized lamedb v4 structure; no changes written')
    present = {identity(line) for line in match['body'].splitlines()}
    pending = {key: value for key, value in records if key not in present}
    if not pending:
        return text, 0
    point = match.end('body')
    insert = '\n'.join(pending.values()) + '\n'
    return text[:point] + insert + text[point:], len(pending)


def add_v5(text, records):
    if not text.startswith('eDVB services /5/'):
        raise ValueError('Unrecognized lamedb v5 structure; no changes written')
    lines = text.splitlines(keepends=True)
    present = {identity(line[2:].partition(',')[0]) for line in lines if line.startswith('t:')}
    pending = {key: value for key, value in records if key not in present}
    if not pending:
        return text, 0
    # The v5 format allows tuning and service records in any order.
    return text.rstrip('\r\n') + '\n' + '\n'.join(pending.values()) + '\n', len(pending)
