"""XC Abertis remote-first control panel.

Workers never touch Enigma widgets. Their results are delivered on the GUI timer.
"""
import queue
import re
import threading
from pathlib import Path

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Plugins.Plugin import PluginDescriptor
from Screens.InputBox import InputBox
from Screens.Screen import Screen
from enigma import eDVBDB, eTimer
from . import core, keys, runtime

VERSION = "0.6"
BASE = Path(__file__).resolve().parent

# All sizes fit a 1280x720 desktop; Enigma scales them with the active skin.
SKIN = '''<screen name="XCAbertis" position="center,center" size="1180,660" flags="wfNoBorder" title="XC Abertis" backgroundColor="#0d1520">
    <eLabel position="0,0" size="1180,4" backgroundColor="#42d6c8" />
    <widget name="logo" position="38,28" size="64,64" pixmap="%s" alphatest="blend" />
    <eLabel text="XC Abertis" position="120,27" size="760,46" font="Regular;36" foregroundColor="#f2f7fc" backgroundColor="#0d1520" />
    <eLabel text="HISPASAT 30W  /  CHANNEL MANAGER" position="123,78" size="850,25" font="Regular;18" foregroundColor="#8da6b9" backgroundColor="#0d1520" />
    <widget name="version" position="1000,41" size="136,30" font="Regular;20" halign="right" foregroundColor="#8da6b9" backgroundColor="#0d1520" />
    <eLabel position="40,122" size="350,76" backgroundColor="#142230" />
    <eLabel position="414,122" size="350,76" backgroundColor="#142230" />
    <eLabel position="788,122" size="350,76" backgroundColor="#142230" />
    <eLabel text="PLAYBACK" position="60,132" size="300,22" font="Regular;16" foregroundColor="#8da6b9" backgroundColor="#142230" />
    <eLabel text="CHANNELS" position="434,132" size="300,22" font="Regular;16" foregroundColor="#8da6b9" backgroundColor="#142230" />
    <eLabel text="KEY FILE" position="808,132" size="300,22" font="Regular;16" foregroundColor="#8da6b9" backgroundColor="#142230" />
    <widget name="playback_state" position="60,158" size="310,30" font="Regular;24" foregroundColor="#75e4cf" backgroundColor="#142230" />
    <widget name="channel_count" position="434,158" size="310,30" font="Regular;24" foregroundColor="#f2f7fc" backgroundColor="#142230" />
    <widget name="key_state" position="808,158" size="310,30" font="Regular;24" foregroundColor="#f2f7fc" backgroundColor="#142230" />
    <eLabel text="ACTIONS" position="42,211" size="350,20" font="Regular;16" foregroundColor="#8da6b9" backgroundColor="#0d1520" />
    <eLabel text="UP / DOWN to select     OK to open" position="650,211" size="488,20" font="Regular;16" halign="right" foregroundColor="#8da6b9" backgroundColor="#0d1520" />
    <widget name="menu" position="40,240" size="550,276" itemHeight="46" font="Regular;23" backgroundColor="#142230" foregroundColor="#dae5ee" backgroundColorSelected="#136d72" foregroundColorSelected="#ffffff" scrollbarMode="showNever" />
    <eLabel position="614,240" size="524,276" backgroundColor="#142230" />
    <eLabel position="614,240" size="3,276" backgroundColor="#254254" />
    <widget name="action_title" position="642,263" size="466,34" font="Regular;25" foregroundColor="#f2f7fc" backgroundColor="#142230" />
    <widget name="action_help" position="642,310" size="466,140" font="Regular;21" foregroundColor="#afc2d1" backgroundColor="#142230" />
    <widget name="action_hint" position="642,470" size="466,30" font="Regular;17" foregroundColor="#75e4cf" backgroundColor="#142230" />
    <widget name="status" position="42,536" size="1096,52" font="Regular;19" foregroundColor="#afc2d1" backgroundColor="#0d1520" />
    <widget name="progress" position="40,595" size="1098,4" borderWidth="0" backgroundColor="#254254" foregroundColor="#42d6c8" />
    <eLabel position="40,622" size="10,10" backgroundColor="#f1767b" />
    <eLabel position="318,622" size="10,10" backgroundColor="#65d4a1" />
    <eLabel position="596,622" size="10,10" backgroundColor="#edc970" />
    <eLabel position="874,622" size="10,10" backgroundColor="#77b7ed" />
    <widget name="red" position="61,614" size="230,29" font="Regular;20" foregroundColor="#f2f7fc" backgroundColor="#0d1520" />
    <widget name="green" position="339,614" size="230,29" font="Regular;20" foregroundColor="#f2f7fc" backgroundColor="#0d1520" />
    <widget name="yellow" position="617,614" size="230,29" font="Regular;20" foregroundColor="#f2f7fc" backgroundColor="#0d1520" />
    <widget name="blue" position="895,614" size="230,29" font="Regular;20" foregroundColor="#f2f7fc" backgroundColor="#0d1520" />
</screen>''' % str(BASE / "header.png")

ACTIONS = (
    ("  Enable / refresh", "enable", "Ready to watch", "Enable playback and add the XC Abertis bouquet to your channel list. Refresh keeps your saved channels.", "GREEN  Enable / refresh"),
    ("  Search channels", "search", "Find available channels", "Scan the Abertis feeds on Hispasat 30W. Live TV pauses during the scan and returns when it finishes.", "YELLOW  Search channels"),
    ("  Update keys", "update_keys", "Keep keys up to date", "Download Abertis keys from the default and configured sources. A backup is saved before each change.", "BLUE  Update keys"),
    ("  Select key file", "keyfile", "Choose a key file", "Select the SoftCam.Key file used for playback. Automatic detection is used until you choose a file.", "OK  Select file path"),
    ("  Diagnostics", "diagnostics", "Check reception", "View tuner lock, signal, playback and update status. Use this page if a channel does not open.", "OK or MENU  Open diagnostics"),
    ("  Disable playback", "disable", "Turn playback off", "Disable XC Abertis playback. The channel list and key file remain available for the next time.", "OK  Disable playback"),
)


def _safe_message(value):
    """Do not show authentication details in failures returned by libraries."""
    text = str(value)
    text = re.sub(r"https?://[^\s<>]+", "[source URL]", text)
    return text[:2400]


class DiagnosticsScreen(Screen):
    skin = '''<screen position="center,center" size="1100,620" flags="wfNoBorder" title="XC Abertis diagnostics" backgroundColor="#0d1520">
        <eLabel position="0,0" size="1100,4" backgroundColor="#42d6c8" />
        <eLabel text="Diagnostics" position="38,28" size="1000,44" font="Regular;32" foregroundColor="#f2f7fc" backgroundColor="#0d1520" />
        <widget name="text" position="40,94" size="1020,452" font="Regular;20" foregroundColor="#afc2d1" backgroundColor="#0d1520" scrollbarMode="showOnDemand" />
        <eLabel position="40,566" size="1020,1" backgroundColor="#254254" />
        <eLabel text="RED / BACK   Close" position="40,580" size="480,30" font="Regular;20" foregroundColor="#f1767b" backgroundColor="#0d1520" />
        <eLabel text="GREEN   Refresh     UP / DOWN   Scroll" position="520,580" size="540,30" font="Regular;20" halign="right" foregroundColor="#75e4cf" backgroundColor="#0d1520" />
    </screen>'''

    def __init__(self, session):
        from Components.ScrollLabel import ScrollLabel
        Screen.__init__(self, session)
        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "cancel": self.close, "ok": self.close, "red": self.close,
            "green": self.refresh, "up": self["text"].pageUp,
            "down": self["text"].pageDown, "left": self["text"].pageUp,
            "right": self["text"].pageDown,
        }, -2)
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        try:
            details = runtime.diagnostics()
            state = keys.status()
            details += "\n\nKEY UPDATES\nSources: %s\nAbertis keys: %s\nLast result: %s" % (
                state.get("source_count", 0), state.get("key_count", 0),
                state.get("last_message") or "No update performed yet.")
            if state.get("error"):
                details += "\nUpdate error: " + str(state["error"])
        except Exception as exc:
            details = "Diagnostics unavailable: " + str(exc)
        self["text"].setText(_safe_message(details))


class DirectScreen(Screen):
    skin = SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["logo"] = Pixmap()
        self["version"] = Label("v" + VERSION)
        self["menu"] = MenuList([(row[0], row[1]) for row in ACTIONS])
        for name in ("playback_state", "channel_count", "key_state", "action_title", "action_help", "action_hint", "status"):
            self[name] = Label("")
        self["progress"] = ProgressBar()
        self["progress"].setValue(0)
        self["red"] = Label("Close")
        self["green"] = Label("Enable / refresh")
        self["yellow"] = Label("Search channels")
        self["blue"] = Label("Update keys")
        self._busy = None
        self._closed = False
        self._close_after_scan = False
        self._worker_queue = queue.Queue()
        self._worker_done = None
        self._scan = None
        self._activity_tick = 0
        self._poll_timer = eTimer()
        self._poll_timer.callback.append(self._poll_worker)
        self._notice_timer = eTimer()
        self._notice_timer.callback.append(self._ready)
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions", "MenuActions", "DirectionActions"], {
            "red": self.request_close, "cancel": self.request_close,
            "green": self.enable, "yellow": self.search, "blue": self.update_keys,
            "menu": self.diagnostics, "ok": self.select,
            "up": self["menu"].up, "down": self["menu"].down,
            "left": self["menu"].pageUp, "right": self["menu"].pageDown,
        }, -2)
        self["menu"].onSelectionChanged.append(self.selection_changed)
        self.onLayoutFinish.append(self._layout_ready)
        self.onClose.append(self._cleanup)

    def _layout_ready(self):
        self.selection_changed()
        self.show_state()
        self._ready()

    def selection_changed(self):
        item = self["menu"].getCurrent()
        if not item:
            return
        row = next((row for row in ACTIONS if row[1] == item[1]), ACTIONS[0])
        self["action_title"].setText(row[2])
        self["action_help"].setText(row[3])
        self["action_hint"].setText(row[4])

    def select(self):
        item = self["menu"].getCurrent()
        if item:
            getattr(self, item[1])()

    def _ready(self):
        if not self._busy and not self._closed:
            self["status"].setText("Choose an action, then press OK.  MENU opens diagnostics.")
            self["progress"].setValue(0)

    def show_state(self):
        if self._closed:
            return
        enabled = (core.CONFIG / "enabled").exists()
        self["playback_state"].setText("Enabled" if enabled else "Disabled")
        try:
            self["channel_count"].setText("%d saved" % len(core.channels()))
        except Exception:
            self["channel_count"].setText("Unavailable")
        try:
            path = core.find_keyfile()
            self["key_state"].setText("Ready" if Path(path).is_file() else "Not found")
        except Exception:
            self["key_state"].setText("Setup needed")

    def _notice(self, message, error=False):
        if self._closed:
            return
        self._notice_timer.stop()
        self["status"].setText(_safe_message(message))
        if not error and not self._busy:
            self._notice_timer.start(9000, True)

    def _require_idle(self):
        if self._busy:
            self._notice("%s is in progress. Please wait." % self._busy)
            return False
        return True

    def _start_worker(self, title, operation, callback):
        if not self._require_idle():
            return
        self._busy = title
        self._worker_done = callback
        self._activity_tick = 0
        self._notice_timer.stop()
        self["status"].setText(title + "...")
        self["progress"].setValue(0)
        result = self._worker_queue
        # Capture only the queue and operation, never the Screen in the worker.
        def work():
            try:
                result.put((True, operation()))
            except Exception as exc:
                result.put((False, _safe_message(exc)))
        threading.Thread(target=work, daemon=True).start()
        self._poll_timer.start(150)

    def _poll_worker(self):
        if self._closed:
            return
        try:
            success, result = self._worker_queue.get_nowait()
        except queue.Empty:
            # Activity indicator only; no invented completion percentage.
            self._activity_tick = (self._activity_tick + 1) % 100
            self["progress"].setValue(10 + self._activity_tick % 70)
            return
        self._poll_timer.stop()
        callback = self._worker_done
        self._worker_done = None
        self._busy = None
        self["progress"].setValue(100 if success else 0)
        try:
            callback(success, result)
        except Exception as exc:
            runtime.log("Control panel: " + _safe_message(exc))
            self._notice("Action failed: " + str(exc), error=True)
        self.show_state()

    def enable(self):
        def check():
            core.check_tool()
            core.find_keyfile()
        self._start_worker("Checking playback", check, self._enable_checked)

    def _enable_checked(self, success, result):
        if not success:
            self._notice("Cannot enable playback: " + str(result), error=True)
            return
        if runtime.manager is None:
            runtime.manager = runtime.Manager(self.session)
        runtime.manager.start(checked=True)
        db = eDVBDB.getInstance()
        db.saveServicelist()
        count = core.install_bouquet()
        db.reloadServicelist()
        db.reloadBouquets()
        runtime.manager.reload_catalog()
        core.CONFIG.mkdir(parents=True, exist_ok=True)
        (core.CONFIG / "enabled").touch()
        self._notice("Playback enabled. %s channels added to your XC Abertis bouquet." % count)

    def update_keys(self):
        self._start_worker("Updating keys", keys.update, self._keys_done)

    def _keys_done(self, success, result):
        self._notice(str(result) if success else "Update failed: " + str(result), error=not success)

    def search(self):
        if not self._require_idle():
            return
        from . import scan
        self._busy = "Channel search"
        self._notice_timer.stop()
        self["red"].setText("Cancel search")
        self["status"].setText("Preparing channel search...")
        self["progress"].setValue(0)
        try:
            self._scan = scan.start_scan(self.session, self._scan_progress, self._scan_done)
        except Exception as exc:
            self._scan_done({"ok": False, "message": str(exc)})

    def _scan_progress(self, progress):
        if self._closed:
            return
        if isinstance(progress, dict):
            self["progress"].setValue(max(0, min(100, int(progress.get("percent", 0)))))
            self["status"].setText(_safe_message(progress.get("message", "Searching...")))
        else:
            self["status"].setText(_safe_message(progress))

    def _scan_done(self, result):
        self._scan = None
        self._busy = None
        if self._closed:
            return
        self["red"].setText("Close")
        success = bool(result.get("ok"))
        self["progress"].setValue(100 if success else 0)
        self._notice(result.get("message", "Search finished."), error=not success)
        self.show_state()
        if self._close_after_scan:
            self.close()

    def keyfile(self):
        if not self._require_idle():
            return
        try:
            initial = str(core.find_keyfile())
        except Exception:
            initial = "/usr/keys/SoftCam.Key"
        self.session.openWithCallback(self.set_keyfile, InputBox, title="SoftCam.Key file path", text=initial)

    def set_keyfile(self, path):
        if path is None:
            return
        path = str(path).strip()
        if not path:
            return
        if not Path(path).is_absolute() or not Path(path).is_file():
            self._notice("File not found. Enter the full path to an existing SoftCam.Key file.", error=True)
            return
        try:
            core.CONFIG.mkdir(parents=True, exist_ok=True)
            core.atomic(core.CONFIG / "keyfile", path + "\n")
            self.show_state()
            self._notice("Key file selected. Press GREEN to enable or refresh playback.")
        except Exception as exc:
            self._notice("Could not save key file: " + str(exc), error=True)

    def disable(self):
        if not self._require_idle():
            return
        try:
            if runtime.manager:
                runtime.manager.stop()
            else:
                (core.CONFIG / "enabled").unlink(missing_ok=True)
            self.show_state()
            self._notice("Playback disabled. Your channels and key file have been kept.")
        except Exception as exc:
            self._notice(str(exc), error=True)

    def diagnostics(self):
        self.session.open(DiagnosticsScreen)

    def request_close(self):
        if self._scan is not None:
            self._close_after_scan = True
            self._notice("Stopping channel search and restoring live TV...")
            self._scan.cancel()
            return
        self.close()

    def _cleanup(self):
        self._closed = True
        self._poll_timer.stop()
        self._notice_timer.stop()
        if self._scan is not None:
            self._scan.cancel()


def main(session, **kwargs):
    session.open(DirectScreen)


def Plugins(**kwargs):
    return [
        PluginDescriptor(name="XC Abertis", description="Hispasat channels, keys and reception", where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
        PluginDescriptor(name="XC Abertis", where=PluginDescriptor.WHERE_SESSIONSTART, fnc=runtime.session_start),
    ]
