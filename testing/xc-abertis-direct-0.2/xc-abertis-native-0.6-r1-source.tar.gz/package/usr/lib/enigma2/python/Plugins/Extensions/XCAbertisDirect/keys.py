# SPDX-License-Identifier: MIT
# Copyright (C) 2026 XC contributors.
"""XC key-file updater: bounded downloads, validation and atomic replacement."""
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import time
from urllib.request import Request, urlopen
from . import core

DEFAULT_URL = 'https://raw.githubusercontent.com/MOHAMED19OS/SoftCam_Emu/main/SoftCam.Key'
BEGIN, END = '; XC ABERTIS BEGIN', '; XC ABERTIS END'
MAX_BYTES = 2 * 1024 * 1024
OSCAM_DIRS = ('/etc/tuxbox/config', '/etc/tuxbox/config/oscam',
              '/etc/tuxbox/config/oscam-emu', '/etc/tuxbox/config/ncam', '/etc/oscam', '/usr/keys')


def record(line):
    """Decode the public SoftCam F-record grammar without interpreting its secret."""
    fields = line.strip().split(None, 4)
    if len(fields) < 4 or fields[0].upper() != 'F':
        return None
    ident, index, value = fields[1:4]
    if not (len(ident) == 8 and 2 <= len(index) <= 8 and len(value) == 16):
        return None
    if any(c not in '0123456789abcdefABCDEF' for c in ident + index + value):
        return None
    return ident.upper(), index.upper(), value.upper(), fields[4] if len(fields) == 5 else ''


def parse(text):
    result = {}
    for line in text.splitlines():
        entry = record(line)
        if entry and 'abertis' in entry[3].lower():
            ident, index, value, _ = entry
            if ident not in result:
                result[ident] = 'F %s %s %s ; ABERTIS' % (ident, index, value)
    return result


def urls():
    sources = []
    preference = core.CONFIG / 'key-urls'
    if preference.is_file():
        for line in preference.read_text(errors='replace').splitlines():
            candidate = line.strip()
            if candidate.startswith('url='):
                candidate = candidate.partition('=')[2].strip()
            if candidate.startswith(('https://', 'http://')):
                sources.append(candidate)
    else:
        sources.append(DEFAULT_URL)
    directories = set(OSCAM_DIRS)
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if 'oscam' not in (proc / 'exe').resolve().name.lower():
                continue
            args = (proc / 'cmdline').read_bytes().decode().split('\0')
            for position, argument in enumerate(args):
                if argument in ('-c', '--config-dir') and position + 1 < len(args):
                    directories.add(args[position + 1])
                elif argument.startswith('-c') and len(argument) > 2:
                    directories.add(argument[2:])
                elif argument.startswith('--config-dir='):
                    directories.add(argument.partition('=')[2])
        except (OSError, UnicodeError):
            continue
    for directory in sorted(directories):
        for filename in ('oscam.server', 'ncam.server'):
            try:
                lines = (Path(directory) / filename).read_text(errors='replace').splitlines()
            except OSError:
                continue
            for line in lines:
                name, separator, value = line.partition('=')
                if separator and name.strip().lower() == 'device':
                    url = value.strip().split()[0] if value.strip() else ''
                    if url.startswith(('https://', 'http://')):
                        sources.append(url)
    return list(dict.fromkeys(sources))[:16]


def merge(text, incoming):
    # Validate marker structure first so an interrupted/manual edit cannot erase data.
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if line == BEGIN]
    ends = [i for i, line in enumerate(lines) if line == END]
    if len(starts) != len(ends) or len(starts) > 1 or (starts and starts[0] >= ends[0]):
        raise ValueError('Invalid update block; key file was not changed.')
    if starts:
        lines = lines[:starts[0]] + lines[ends[0] + 1:]
    preserved = []
    for line in lines:
        entry = record(line)
        if not entry or entry[0] not in incoming:
            preserved.append(line)
    return '\n'.join(preserved + [BEGIN] + [incoming[k] for k in sorted(incoming)] + [END]) + '\n'


def _fetch(url):
    request = Request(url, headers={'User-Agent': 'XC-Abertis/0.6'})
    with urlopen(request, timeout=15) as response:
        body = response.read(MAX_BYTES + 1)
    if len(body) > MAX_BYTES:
        raise ValueError('Source exceeds the download limit.')
    return body.decode('utf-8', errors='replace')


def status():
    try:
        result = json.loads((core.CONFIG / 'keys-status.json').read_text())
    except (OSError, ValueError):
        result = {}
    result.update(source_count=len(urls()), default_source=not (core.CONFIG / 'key-urls').exists(), auto_enabled=False)
    try:
        target = core.find_keyfile()
        result.update(keyfile=str(target), key_count=len(parse(target.read_text(errors='replace'))))
    except (OSError, RuntimeError) as error:
        result.update(key_count=0, error=str(error))
    return result


def replace_file(target, text):
    if target.exists():
        destination = core.CONFIG / 'backup' / ('keys-%d' % time.time_ns())
        destination.mkdir(parents=True, mode=0o700)
        shutil.copyfile(target, destination / 'SoftCam.Key')
        os.chmod(destination / 'SoftCam.Key', 0o600)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.xc-keyfile-', dir=str(target.parent))
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, target)
    finally:
        Path(name).unlink(missing_ok=True)


def update(auto=False):
    core.CONFIG.mkdir(parents=True, exist_ok=True)
    with (core.CONFIG / 'keys.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('A key update is already running.')
        if auto and time.time() - status().get('last_success', 0) < 72000:
            return 'Keys were updated recently.'
        try:
            target = core.find_keyfile().resolve()
        except core.KeyfileNotFound:
            target = Path('/usr/keys/SoftCam.Key')
        received, failed = {}, 0
        for source in urls():
            try:
                entries = parse(_fetch(source))
                for ident, line in entries.items():
                    received.setdefault(ident, line)
            except Exception:
                failed += 1
        if not received:
            raise RuntimeError('No valid Abertis keys received. Existing file unchanged.')
        previous = target.read_text(errors='replace') if target.exists() else ''
        updated = merge(previous, received)
        if updated != previous:
            replace_file(target, updated)
            message = 'Updated %d Abertis records; previous file backed up.' % len(received)
        else:
            message = 'Already up to date (%d Abertis records).' % len(received)
        if failed:
            message += ' %d source(s) unavailable.' % failed
        core.atomic(core.CONFIG / 'keyfile', str(target) + '\n')
        state = dict(last_success=time.time(), last_message=message, key_count=len(received))
        core.atomic(core.CONFIG / 'keys-status.json', json.dumps(state) + '\n')
        return message
