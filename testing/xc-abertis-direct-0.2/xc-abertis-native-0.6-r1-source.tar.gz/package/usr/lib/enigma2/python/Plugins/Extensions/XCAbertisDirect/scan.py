# SPDX-License-Identifier: MIT
# Copyright (C) 2026 XC contributors.
"""Feed search using the same XC-owned input path as playback."""
import os
import json
import queue
import re
import select
import subprocess
import threading
import time
from . import core,runtime,transport

_active=None

class Sections:
    def __init__(self):self.buffer=b'';self.cc=None
    def push(self,p):
        if len(p)!=188 or p[0]!=0x47 or p[1]&0x80:return []
        afc=(p[3]>>4)&3
        if afc not in (1,3):return []
        cc=p[3]&15
        if self.cc==cc:return []
        if self.cc is not None and cc!=(self.cc+1)&15:self.buffer=b''
        self.cc=cc;pos=4+(1+p[4] if afc==3 else 0)
        if pos>=188:return []
        payload=p[pos:];result=[]
        def consume(data):
            self.buffer+=data;out=[]
            while len(self.buffer)>=3:
                if self.buffer[0]==255:self.buffer=b'';break
                n=3+(((self.buffer[1]&15)<<8)|self.buffer[2])
                if n<7 or n>4096:self.buffer=b'';break
                if len(self.buffer)<n:break
                out.append(self.buffer[:n]);self.buffer=self.buffer[n:]
            return out
        if p[1]&0x40:
            pointer=payload[0]
            if pointer+1>len(payload):self.buffer=b'';return []
            if self.buffer:result+=consume(payload[1:1+pointer])
            self.buffer=b'';payload=payload[1+pointer:]
        elif not self.buffer:return []
        result+=consume(payload)
        return result

def valid_crc(section):
    value=0xffffffff
    for byte in section:
        value^=byte<<24
        for _ in range(8):value=((value<<1)^(0x04c11db7 if value&0x80000000 else 0))&0xffffffff
    return value==0


def read_section(demux,pid,table,cancel,seconds=3):
    parser=Sections();buf=b'';deadline=time.monotonic()+seconds
    with transport.feed(demux,pid) as fd:
        while time.monotonic()<deadline and not cancel.is_set():
            if not select.select([fd],[],[],0.1)[0]:continue
            try:data=os.read(fd,188*128)
            except BlockingIOError:continue
            if not data:break
            buf+=data
            while len(buf)>=188:
                if buf[0]!=0x47:
                    idx=buf.find(b'\x47',1);buf=buf[idx:] if idx>=0 else b'';continue
                packet,buf=buf[:188],buf[188:]
                for section in parser.push(packet):
                    if len(section)>=8 and section[0]==table and section[5]&1 and valid_crc(section):return section
    return None

def feed_pids(demux,sid,cancel):
    pat=read_section(demux,0,0,cancel)
    if not pat:return []
    pmtpid=None
    for i in range(8,len(pat)-4,4):
        if i+4>len(pat)-4:break
        if int.from_bytes(pat[i:i+2],'big')==sid:pmtpid=((pat[i+2]&31)<<8)|pat[i+3];break
    if pmtpid is None:return []
    pmt=read_section(demux,pmtpid,2,cancel)
    if not pmt or len(pmt)<16:return []
    pos=12+(((pmt[10]&15)<<8)|pmt[11]);pids=[]
    while pos+5<=len(pmt)-4:
        kind=pmt[pos];pid=((pmt[pos+1]&31)<<8)|pmt[pos+2]
        length=((pmt[pos+3]&15)<<8)|pmt[pos+4]
        if kind==0x90:pids.append(pid)
        pos+=5+length
    return pids

def programs(text,feed):
    channels=[]
    for line in text.splitlines():
        try:
            info=json.loads(line)
            program=int(info['program']);kind=int(info['service_type'])
            if not 0<program<65536 or not 0<kind<256:continue
            title=str(info['name']).replace('\n',' ').replace('\r',' ').strip()
            channel=dict(feed,program=program,service_type=kind,
                         name=title or 'Abertis %d/%d'%(feed['pid'],program),group='Search')
            channels.append(channel)
        except (ValueError,TypeError,KeyError):continue
    return channels

class Scan:
    def __init__(self,session,progress,done):
        from enigma import eTimer
        self.session=session;self.progress=progress;self.done=done;self.cancelled=threading.Event()
        self.messages=queue.Queue();self.found=[];self.result=None;self.restore=None
        self.manager=runtime.manager or runtime.Manager(session);runtime.manager=self.manager
        if self.manager.scan_active:raise RuntimeError('A channel search is already running.')
        from Components.NimManager import nimmanager
        if not any(any(int(s[0])==3300 for s in nimmanager.getSatListForNim(n.slot)) for n in nimmanager.nim_slots if n.isCompatible('DVB-S')):
            raise RuntimeError('Configure Hispasat 30W on a satellite tuner before searching.')
        self.keyfile=core.find_keyfile();self.manager.scan_active=True
        self.restore=session.nav.getCurrentlyPlayingServiceReference()
        if self.manager.lease:self.manager.lease.cancel.set();self.manager.lease.event.set()
        session.nav.stopService()
        self.timer=eTimer();self.timer.callback.append(self.tick);self.timer.start(100)
        threading.Thread(target=self.work,daemon=True).start()
    def cancel(self):self.cancelled.set()
    def work(self):
        locked=0;failed=0
        try:
            feeds={}
            for c in core.channels():feeds.setdefault((c['ns'],c['tsid'],c['onid'],c['sid']),c)
            for i,feed in enumerate(feeds.values()):
                if self.cancelled.is_set():break
                self.messages.put({'percent':int(i*100/len(feeds)),'message':'Feed %d / %d: %s'%(i+1,len(feeds),feed['name'])})
                lease=self.manager.request(feed)
                try:
                    deadline=time.monotonic()+28
                    while not lease.event.wait(.1):
                        if self.cancelled.is_set() or time.monotonic()>deadline:break
                    if self.cancelled.is_set():break
                    if not lease.event.is_set() or lease.error or lease.cancel.is_set():failed+=1;continue
                    locked+=1
                    pids=feed_pids(lease.demux,feed['sid'],self.cancelled)
                    # Some feed PATs are unavailable; retain known feed PIDs as fallback.
                    pids=list(dict.fromkeys(pids+[c['pid'] for c in core.channels() if (c['ns'],c['tsid'],c['onid'],c['sid'])==(feed['ns'],feed['tsid'],feed['onid'],feed['sid'])]))
                    for pid in pids:
                        if self.cancelled.is_set():break
                        candidate=dict(feed,pid=pid)
                        with transport.feed(lease.demux,pid) as fd:
                            cmd=core.extractor_command(candidate,fd,self.keyfile,list_only=True)
                            process=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,pass_fds=(fd,),env=dict(os.environ,LD_LIBRARY_PATH=str(core.HERE/'lib')))
                            try:
                                end=time.monotonic()+12;data=b''
                                while time.monotonic()<end and not self.cancelled.is_set():
                                    if select.select([process.stdout],[],[],.1)[0]:
                                        chunk=os.read(process.stdout.fileno(),16384)
                                        if not chunk:break
                                        data+=chunk
                                        if len(data)>512*1024:break
                                self.found+=programs(data.decode('utf-8','replace'),candidate)
                            finally:
                                if process.poll() is None:process.terminate()
                                try:process.wait(timeout=2)
                                except subprocess.TimeoutExpired:process.kill();process.wait()
                                process.stdout.close()
                finally:lease.cancel.set();lease.event.set();lease.finished.set()
            if self.cancelled.is_set():self.result={'ok':False,'message':'Search cancelled. Live TV restored.'}
            elif not locked:self.result={'ok':False,'message':'No feed locked. Check Hispasat reception and tuner settings.'}
            elif not self.found:self.result={'ok':False,'message':'Feed locked, but no channels decoded. Check the key file and reception.'}
            else:self.result={'ok':True,'message':'Search completed. %d feed(s) did not lock.'%failed}
        except Exception as exc:self.result={'ok':False,'message':'Search failed: '+str(exc)}
    def tick(self):
        while True:
            try:self.progress(self.messages.get_nowait())
            except queue.Empty:break
        if self.result is None:return
        # Wait for manager to release the reserved frontend before restoring live TV.
        if self.manager.lease is not None:return
        self.timer.stop();result=self.result
        try:
            if result['ok']:
                added=core.merge_channels(self.found);core.install_bouquet();self.manager.reload_catalog()
                from enigma import eDVBDB
                eDVBDB.getInstance().reloadServicelist()
                eDVBDB.getInstance().reloadBouquets()
                result['message']='Search complete: %d new channels saved.'%added;result['channels']=added
        except Exception as exc:result={'ok':False,'message':'Could not save search: '+str(exc)}
        finally:
            self.manager.scan_active=False
            try:
                if self.restore:self.session.nav.playService(self.restore)
            except Exception as exc:
                result={'ok':False,'message':'Search ended; select a live channel to resume TV.'}
                runtime.log('Restore service failed: '+str(exc))
        global _active
        _active=None
        self.done(result)

def start_scan(session,on_progress,on_done):
    global _active
    if _active is not None:raise RuntimeError('A channel search is already running.')
    _active=Scan(session,on_progress,on_done)
    return _active
