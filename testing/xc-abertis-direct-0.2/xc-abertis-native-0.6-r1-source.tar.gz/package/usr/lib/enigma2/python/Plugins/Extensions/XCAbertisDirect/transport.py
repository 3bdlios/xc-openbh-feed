"""Read one PID from the XC-reserved demux, without changing global routing.
Linux DVB ABI: dmx_pes_filter_params and DMX_OUT_TSDEMUX_TAP.
"""
import fcntl
import os
import struct
from contextlib import contextmanager

@contextmanager
def feed(demux,pid):
    if not 0<=int(demux)<32 or not 0<=int(pid)<=8192:
        raise ValueError('Invalid demux/PID')
    fd=os.open('/dev/dvb/adapter0/demux%d'%demux,os.O_RDWR|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        fcntl.ioctl(fd,0x6f2d,2*1024*1024)
        # frontend=0, TSDEMUX_TAP=3, PES_OTHER=20, IMMEDIATE_START=4
        fcntl.ioctl(fd,0x40146f2c,struct.pack('=H2xiiiI',pid,0,3,20,4))
        yield fd
    finally:
        os.close(fd)
