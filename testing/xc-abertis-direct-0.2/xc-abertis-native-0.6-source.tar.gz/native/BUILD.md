# Building XC Abertis 0.6

Requirements: C compiler, Python 3, autotools/libtool, GNU make/binutils. The
bundled libdvbcsa source archive is the exact public commit recorded in
THIRD-PARTY.txt, not a binary extracted from firmware.

Run `native/build-host.sh` to build a host library/engine and run the synthetic
protocol and Python tests. Tests use generated values, no real broadcaster keys.

For the receiver run `native/build-target.sh` with Clang, an AArch64 Linux
sysroot and matching binutils. Set `XC_SYSROOT`, `XC_BINUTILS`, and optionally
`XC_GCCLIB` for their locations. Defaults reference the adjacent XC project's
OpenBH build environment. Target output replaces the staged engine and library.
Then run `python3 build.py` to create the IPK in `output/`.

Python modules run on the receiver's Enigma2 Python. Host tests stub out tuner
operations; they do not establish successful reception, UI rendering, decoder
synchronization, or channel switching on hardware.

The engine relies on libc and private libdvbcsa only. The packaged AArch64 build
requires glibc >= 2.34. No FFmpeg, EX binary, Python bytecode or device credentials
are required or included. New installs start disabled. See README-ar.txt for
current protocol limitations and receiver test procedure.
