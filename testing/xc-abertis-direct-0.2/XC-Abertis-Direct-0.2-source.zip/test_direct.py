import importlib,sys,types,unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).parent/'package/usr/lib/enigma2/python/Plugins/Extensions'
sys.path.insert(0,str(BASE))
from XCAbertisDirect import core,runtime
class Tests(unittest.TestCase):
 def test_all_seed_entries_have_real_transponder_and_program(self):
  data=core.channels();self.assertEqual(len(data),49)
  for c in data:
   self.assertGreater(c['program'],0);self.assertTrue(0<c['pid']<8192)
   self.assertEqual(core.satellite_fields(c['transponder'])['orbital_position'],3300)
 def test_short_transponder_defaults(self):
  f=core.satellite_fields('s 11222000:30000000:0:3:-300:2:0')
  self.assertEqual(f['system'],0);self.assertEqual(f['modulation'],1);self.assertEqual(f['is_id'],-1)
 def test_extractor_uses_selected_channel_and_own_keyfile(self):
  c=core.channels()[0];args=core.extractor_command(c,1,'/tmp/test.key')
  self.assertIn('--dvr',args);self.assertIn('--program',args)
  self.assertEqual(args[-1],'/tmp/test.key');self.assertNotIn('ex-pvr',str(args))
 def test_output_ref_selects_inner_program(self):
  c=core.channels()[0];r=core.service_reference(c)
  self.assertEqual(int(r.split(':')[3],16),c['program']);self.assertIn('127.0.0.1',r)
 def test_ts_probe(self):
  self.assertTrue(runtime.has_ts((b'\x47'+b'\0'*187)*3));self.assertFalse(runtime.has_ts(b'x'*1000))
 def test_catalog_preserves_other_bouquets(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);e=p/'e';e.mkdir();(e/'bouquets.tv').write_text('#NAME TV\n#SERVICE keep\n')
   cfg=p/'config'
   with patch.object(core,'CONFIG',cfg):
    core.install_bouquet(e);core.install_bouquet(e)
   s=(e/'bouquets.tv').read_text();self.assertIn('#SERVICE keep',s);self.assertEqual(s.count('xc_abertis_direct.tv'),1)
 def test_clock_cleanup_before_next_navigation(self):
  m=runtime.Manager.__new__(runtime.Manager);m.jobs=runtime.queue.Queue();m.pending=None
  m.pending_play=('next',(),{});m.original_play=lambda *a,**k:calls.append(a)
  m.raw=object();m.frontend=object();m.lease=runtime.Lease({});m.lease.cancel.set();calls=[]
  m.tick();self.assertEqual(calls,[]);self.assertIsNotNone(m.raw)
  m.lease.finished.set();m.tick();self.assertEqual(calls,[('next',)]);self.assertIsNone(m.raw)
if __name__=='__main__':unittest.main()
