from Components.ActionMap import ActionMap
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from enigma import eDVBDB
from . import core,runtime

class DirectScreen(Screen):
    skin='''<screen position="center,center" size="1000,450" title="XC Abertis Direct — TEST">
    <widget name="status" position="30,25" size="940,290" font="Regular;25" />
    <widget name="red" position="30,360" size="220,50" font="Regular;25" foregroundColor="#ff6060" />
    <widget name="green" position="270,360" size="440,50" font="Regular;25" foregroundColor="#60ff80" />
    <widget name="blue" position="740,360" size="220,50" font="Regular;25" foregroundColor="#70c0ff" />
    </screen>'''
    def __init__(self,session):
        Screen.__init__(self,session)
        self['status']=Label('مسار أبرتيس المباشر — نسخة تجربة\nأداة EX الأصلية لاستخراج البث، والصورة والصوت بمشغّل XC.\nلا يحتاج Astra أو F1/F5، ولا يبدّل مشغّل النظام.\nيتطلب تفعيل هسباسات في التيونر وملف مفاتيح موجود.\nالأصفر: مسار المفاتيح، MENU: تعطيل.\nعطّل إضافة XCAbertis القديمة أولاً إن كانت مفعّلة.')
        self['red']=Label('إغلاق');self['green']=Label('تجهيز القائمة والتفعيل');self['blue']=Label('التشخيص')
        self['actions']=ActionMap(['ColorActions','OkCancelActions','MenuActions'],{'red':self.close,'cancel':self.close,'green':self.enable,'menu':self.disable,'yellow':self.keyfile,'blue':self.diagnostics,'ok':self.diagnostics},-1)
    def enable(self):
        try:
            if runtime.manager is None:runtime.manager=runtime.Manager(self.session)
            core.check_tool();core.find_keyfile()
            runtime.manager.start()
            db=eDVBDB.getInstance();db.saveServicelist();core.install_bouquet();db.reloadBouquets()
            core.CONFIG.mkdir(parents=True,exist_ok=True);(core.CONFIG/'enabled').touch()
            self['status'].setText('تم تجهيز باقة XC Abertis Direct.\nاختر قناة من الباقة الجديدة.\nهذه نسخة أولية؛ يحتاج تشغيل القنوات لتأكيد استقبال البث.')
        except Exception as exc:
            runtime.log(str(exc));self['status'].setText('لم يكتمل التجهيز:\n'+str(exc))
    def keyfile(self):
        from Screens.InputBox import InputBox
        self.session.openWithCallback(self.set_keyfile,InputBox,title='مسار ملف المفاتيح الموجود (SoftCam.Key)',text='/etc/tuxbox/config/SoftCam.Key')
    def set_keyfile(self,path):
        if not path:return
        from pathlib import Path
        if not Path(path).is_absolute() or not Path(path).is_file():
            self['status'].setText('المسار غير موجود؛ لم تتغير الإعدادات.')
            return
        core.CONFIG.mkdir(parents=True,exist_ok=True)
        core.atomic(core.CONFIG/'keyfile',path+'\n')
        self['status'].setText('تم اختيار مسار ملف المفاتيح. اضغط الأخضر للتفعيل.')
    def disable(self):
        try:
            if runtime.manager:runtime.manager.stop()
            else:(core.CONFIG/'enabled').unlink(missing_ok=True)
            self['status'].setText('تم التعطيل. القائمة تبقى محفوظة. يمكن إعادة التفعيل بالأخضر.')
        except Exception as exc:self['status'].setText(str(exc))
    def diagnostics(self):
        try:text=open('/tmp/xc-abertis-direct.log').read()[-3000:]
        except OSError:text='No playback attempt logged.'
        self.session.open(MessageBox,text,type=MessageBox.TYPE_INFO)

def main(session,**kwargs):session.open(DirectScreen)
def Plugins(**kwargs):
    return [PluginDescriptor(name='XC Abertis Direct TEST',description='Direct EX extraction to XC native playback',where=PluginDescriptor.WHERE_PLUGINMENU,icon='plugin.png',fnc=main),PluginDescriptor(name='XC Abertis Direct',where=PluginDescriptor.WHERE_SESSIONSTART,fnc=runtime.session_start)]
