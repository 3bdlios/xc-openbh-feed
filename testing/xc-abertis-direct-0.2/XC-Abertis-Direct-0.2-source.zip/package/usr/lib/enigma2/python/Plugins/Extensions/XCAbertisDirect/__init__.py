"""XC direct Abertis prototype; original EX extractor retained unchanged."""
