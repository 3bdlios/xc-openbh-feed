"""All Enigma/tuner calls stay on the GUI thread; stream I/O stays outside it."""
import json
import os
import queue
import select
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from . import core

manager=None

def log(message):
    p=Path('/tmp/xc-abertis-direct.log')
    try:
        if p.exists() and p.stat().st_size>512*1024:p.replace(str(p)+'.old')
        with p.open('a') as f:f.write(time.strftime('%H:%M:%S ')+str(message)+'\n')
    except OSError:pass

class Lease:
    def __init__(self,channel):
        self.channel=channel;self.event=threading.Event();self.cancel=threading.Event()
        self.finished=threading.Event();self.error=None;self.dvr=None;self.deadline=time.monotonic()+25

class Manager:
    def __init__(self,session):
        from enigma import eTimer
        self.session=session;self.jobs=queue.Queue();self.lease=None
        self.raw=None;self.frontend=None;self.server=None;self.pending=None;self.pending_play=None
        self.original_play=None;self.play_wrapper=None
        self.catalog={c['id']:c for c in json.loads((core.HERE/'data/channels.json').read_text())}
        self.timer=eTimer();self.timer.callback.append(self.tick)
        self.timer.start(100)
    def start(self):
        core.check_tool()
        if Path('/etc/xc-abertis/enabled').exists():
            raise RuntimeError('Disable the old XC Abertis/Astra plugin with Yellow first')
        if self.server:return
        self.server=ThreadingHTTPServer(('127.0.0.1',core.PORT),Handler)
        self.server.manager=self
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
        self.original_play=self.session.nav.playService
        def play(ref,*args,**kwargs):
            if self.lease is not None:
                self.lease.cancel.set();self.lease.event.set()
                self.pending_play=(ref,args,kwargs)
                return 0
            return self.original_play(ref,*args,**kwargs)
        self.play_wrapper=play;self.session.nav.playService=play
        log('Direct HTTP endpoint ready on loopback')
    def stop(self):
        if self.lease is not None:
            raise RuntimeError('Leave the direct Abertis channel first, then disable')
        (core.CONFIG/'enabled').unlink(missing_ok=True)
        if self.play_wrapper is not None and self.session.nav.playService == self.play_wrapper:
            self.session.nav.playService=self.original_play
        if self.server:
            server=self.server;self.server=None
            def shutdown():
                server.shutdown();server.server_close()
            threading.Thread(target=shutdown,daemon=True).start()
        log('Direct plugin disabled')
    def retire(self):
        if self.lease:
            self.lease.cancel.set();self.lease.event.set()
        self.frontend=None;self.raw=None;self.lease=None
    def tune(self,lease):
        from enigma import eDVBResourceManager,eDVBFrontendParametersSatellite,eDVBFrontendParameters
        from Components.NimManager import nimmanager
        self.retire();self.lease=lease
        fields=core.satellite_fields(lease.channel['transponder'])
        candidates=[]
        for slot in nimmanager.nim_slots:
            if not slot.isCompatible('DVB-S'):continue
            sats=nimmanager.getSatListForNim(slot.slot)
            if any(int(s[0])==fields['orbital_position'] for s in sats):candidates.append(slot.slot)
        if not candidates:raise RuntimeError('Hispasat is not configured on any satellite tuner')
        rm=eDVBResourceManager.getInstance()
        for slot in candidates:
            raw=rm.allocateRawChannel(slot)
            if raw:
                self.raw=raw;break
        if self.raw is None:raise RuntimeError('Configured satellite tuner is busy; recordings were not stopped')
        self.frontend=self.raw.getFrontend()
        if self.frontend is None:raise RuntimeError('Cannot acquire satellite frontend')
        # Resource manager reserves and routes the demux; never write global ts1/hiu sources.
        demux=self.raw.reserveDemux();dvr=self.raw.getDvrId()
        if demux<0 or dvr<0 or demux!=dvr:
            raise RuntimeError('Unsupported raw demux/DVR mapping %s/%s'%(demux,dvr))
        lease.dvr=dvr
        sat=eDVBFrontendParametersSatellite()
        for name,value in fields.items():setattr(sat,name,value)
        params=eDVBFrontendParameters();params.setDVBS(sat,False)
        self.frontend.tune(params)
        log('Tuning feed PID %d demux/DVR %d'%(lease.channel['pid'],dvr))
    def tick(self):
        try:
            if self.lease and self.lease.cancel.is_set() and self.lease.finished.is_set():
                self.retire()
            if self.pending_play and self.lease is None:
                ref,args,kwargs=self.pending_play;self.pending_play=None
                self.original_play(ref,*args,**kwargs)
            while True:
                try:job=self.jobs.get_nowait()
                except queue.Empty:break
                if self.pending:
                    self.pending.error='Superseded request';self.pending.cancel.set();self.pending.event.set()
                self.pending=job
                if self.lease:self.lease.cancel.set();self.lease.event.set()
            if self.pending and self.lease is None:
                job=self.pending;self.pending=None
                if not job.cancel.is_set():
                    try:self.tune(job)
                    except Exception as exc:
                        job.error=str(exc);job.cancel.set();job.event.set()
            lease=self.lease
            if lease is not None and not lease.cancel.is_set():
                if not lease.event.is_set():
                    status={};self.frontend.getFrontendStatus(status)
                    if status.get('tuner_locked') or status.get('tuner_state')=='LOCKED':
                        log('Frontend locked; extractor may start');lease.event.set()
                    elif time.monotonic()>lease.deadline:
                        lease.error='Frontend did not lock within 25 seconds';log(lease.error);lease.cancel.set();lease.event.set()
        except Exception as exc:log('GUI service error: '+str(exc))

    def request(self,channel):
        job=Lease(channel);self.jobs.put(job);return job

class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.0'
    def log_message(self,*args):pass
    def do_GET(self):
        import re
        m=re.fullmatch(r'/xc-abertis/(\d+)\.ts',self.path)
        catalog=self.server.manager.catalog
        if not m or int(m.group(1)) not in catalog:self.send_error(404);return
        channel=catalog[int(m.group(1))];lease=None;process=None;sent=False
        try:
            keyfile=core.find_keyfile()
            lease=self.server.manager.request(channel)
            if not lease.event.wait(27):raise RuntimeError('GUI/tuner request timed out')
            if lease.error:raise RuntimeError(lease.error)
            if lease.cancel.is_set():raise RuntimeError('Channel request cancelled')
            env=dict(os.environ,LD_LIBRARY_PATH=str(core.HERE/'lib'))
            with open('/tmp/xc-abertis-extractor.log','ab') as errors:
                process=subprocess.Popen(core.extractor_command(channel,lease.dvr,keyfile),
                    stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=errors,env=env)
                # Require real inner TS before claiming successful HTTP playback.
                deadline=time.monotonic()+12;initial=b''
                while time.monotonic()<deadline and not lease.cancel.is_set():
                    if select.select([process.stdout],[],[],0.2)[0]:
                        data=os.read(process.stdout.fileno(),188*256)
                        if not data:break
                        initial+=data
                        if len(initial)>=188*3:break
                if not has_ts(initial):raise RuntimeError('No valid inner TS: inspect extractor/key/PID log')
                self.send_response(200);self.send_header('Content-Type','video/mp2t');self.end_headers();sent=True
                self.wfile.write(initial);self.wfile.flush();log('Inner TS delivered to XC id=%d'%channel['id'])
                self.connection.settimeout(3)
                last_data=time.monotonic()
                while not lease.cancel.is_set():
                    if not select.select([process.stdout],[],[],0.2)[0]:
                        if time.monotonic()-last_data>10:raise RuntimeError('Inner stream stalled')
                        continue
                    data=os.read(process.stdout.fileno(),188*256)
                    if not data:break
                    last_data=time.monotonic();self.wfile.write(data);self.wfile.flush()
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as exc:
            log('Stream failure: '+str(exc))
            if not sent:
                try:self.send_error(503,str(exc))
                except OSError:pass
        finally:
            if lease:lease.cancel.set()
            if process:
                process.terminate()
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:process.kill();process.wait()
                process.stdout.close()
            if lease:lease.finished.set()

def has_ts(data):
    return any(data[i]==0x47 and data[i+188]==0x47 and data[i+376]==0x47
               for i in range(min(188,max(0,len(data)-376))))

def session_start(reason=0,session=None,**kwargs):
    global manager
    if reason!=0 or session is None:return
    manager=Manager(session)
    if (core.CONFIG/'enabled').exists():
        try:manager.start()
        except Exception as exc:log('Startup failed: '+str(exc))
