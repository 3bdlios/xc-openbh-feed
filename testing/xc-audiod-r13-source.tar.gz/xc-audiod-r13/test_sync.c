#include <assert.h>
#include <stdio.h>
#include "sync_control.h"
static void feed(struct xc_sync *s,int error_ms,int ticks){
 for(int i=0;i<ticks;i++){
  int64_t t=s->valid?s->t+100:0;uint32_t p=(uint32_t)(90000+t*90),v=p;
  xc_observe(s,t,p,v,p-error_ms*90);
 }
}
int main(void){
 assert(xc_delta(32,0xfffffff0U)==48);
 struct xc_sync s={0};feed(&s,100,29);assert(s.ppm==-5000);
 memset(&s,0,sizeof(s));feed(&s,-100,29);assert(s.ppm==5000);
 memset(&s,0,sizeof(s));feed(&s,10,40);assert(s.ppm==0);
 memset(&s,0,sizeof(s));feed(&s,100,19);assert(s.ppm==0);/* needs 3 windows */
 memset(&s,0,sizeof(s));feed(&s,100,29);uint32_t p=s.p,v=s.v;
 for(int i=0;i<4;i++){p+=9000;xc_observe(&s,s.t+100,p,v,p-9000);}assert(s.ppm==0);/* frozen video */
 memset(&s,0,sizeof(s));feed(&s,100,29);
 assert(xc_observe(&s,s.t+100,s.p+900000,s.v+900000,s.p)==-1);assert(s.ppm==0);/* seek/reset */
 memset(&s,0,sizeof(s));for(int i=0;i<60;i++)feed(&s,(i%2)?150:-150,1);assert(s.ppm==0);/* jitter */
 struct xc_start_clock c={0};
 assert(!xc_start_ready(&c,0,90000,90000));
 assert(!xc_start_ready(&c,5,90450,90450));
 assert(xc_start_ready(&c,10,90900,90900));
 /* Thousands of stale decoded frames may arrive within one clock tick.
  * Once ready, do not sleep twice per discarded frame. */
 for(int i=0;i<4000;i++)assert(xc_start_ready(&c,10,90900,90900));
 assert(!xc_start_ready(&c,300,117000,90900));
 memset(&c,0,sizeof(c));
 xc_start_ready(&c,0,90000,90000);
 assert(!xc_start_ready(&c,10,900000,900000));
 puts("PASS: wrap, correction sign and bound, deadband, 3-window agreement, freeze, seek, jitter");
}
