#!/usr/bin/env python3
"""Read-only, shareable Abertis preflight; no keys or account data are read."""
import json
import os
import platform
from pathlib import Path
import socket
import subprocess
import sys

BASE = Path('/usr/lib/enigma2/python/Plugins/Extensions/XCAbertis')

def run(args):
    try:
        p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=10)
        return {'returncode': p.returncode, 'output': p.stdout[-6000:]}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {'error': type(exc).__name__}

def main():
    report = {'machine': platform.machine(), 'kernel': platform.release(),
              'python': platform.python_version(), 'plugins': {}, 'tools': {},
              'network_ports': {}, 'feed_count': 0, 'oscam_processes': []}
    for name in ('XCAbertis', 'Abertis', 'EXAbertis', 'AbertisAutoSwitcher',
                 'CiefpSettingsT2miAbertis'):
        report['plugins'][name] = (BASE.parent / name).is_dir()
    loader = Path('/lib/ld-linux-aarch64.so.1')
    for name in ('astra', 'abertis'):
        p = BASE / 'bin' / name
        item = {'exists': p.is_file(), 'executable': os.access(p, os.X_OK)}
        if loader.exists() and p.exists() and platform.machine() in ('aarch64', 'arm64'):
            item['libraries'] = run([str(loader), '--library-path', str(BASE/'lib'), '--list', str(p)])
        report['tools'][name] = item
    for port in (80, 8001, 9999):
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=1):
                report['network_ports'][str(port)] = 'listening'
        except OSError:
            report['network_ports'][str(port)] = 'not reachable'
    p = Path('/etc/enigma2/lamedb')
    if p.exists():
        lines = p.read_text(errors='replace').splitlines()
        import re
        report['feed_count'] = sum(bool(re.match(r'^Abertis PID \d+', l, re.I)) for l in lines)
        report['lamedb_format'] = lines[0] if lines else 'empty'
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            name = Path(os.readlink(proc/'exe')).name
            if 'oscam' not in name.lower():
                continue
            args = (proc/'cmdline').read_bytes().split(b'\0')
            explicit = any(a in (b'-c', b'--config-dir') or a.startswith(b'--config-dir=') or
                           (a.startswith(b'-c') and len(a)>2) for a in args)
            report['oscam_processes'].append({'pid': int(proc.name), 'executable': name,
                                               'explicit_config_directory': explicit})
        except (OSError, ValueError):
            pass
    report['demux_devices'] = sorted(str(p) for p in Path('/dev/dvb/adapter0').glob('demux*'))
    report['xc_abertis_enabled'] = Path('/etc/xc-abertis/enabled').exists()
    report['xc_abertis_config_exists'] = Path('/etc/xc-abertis/astra.conf').exists()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0

if __name__ == '__main__':
    sys.exit(main())
