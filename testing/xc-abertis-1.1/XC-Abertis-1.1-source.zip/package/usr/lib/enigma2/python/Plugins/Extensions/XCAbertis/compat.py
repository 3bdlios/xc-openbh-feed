def connect_timer(timer, callback):
    signal = getattr(timer, "timeout", None)
    if hasattr(signal, "connect"):
        return signal.connect(callback)
    timer.callback.append(callback)
    return callback
