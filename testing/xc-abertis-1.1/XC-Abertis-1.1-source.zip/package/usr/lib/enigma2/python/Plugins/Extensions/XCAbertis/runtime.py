"""Thread workers only do I/O; Enigma navigation and timers stay on GUI thread."""
import threading
from enigma import eTimer
from .compat import connect_timer
from . import autostart, lamedb_fix, xc_setup, logger

session = None
busy = False
message = 'Disabled — press Green to prepare and enable'
_timer = None
_connection = None
_result = None
_thread = None


def disable_hook():
    hook = autostart._hook
    if hook:
        hook.disabled = True
        hook._cancel()
        for name in ('step_timer', 'poll_timer', 'debug_timer'):
            timer = getattr(hook, name, None)
            if timer: timer.stop()
        nav = getattr(hook, 'nav', None)
        callbacks = getattr(nav, 'serviceStarted', [])
        if hook._on_service_started in callbacks:
            callbacks.remove(hook._on_service_started)
    autostart._hook = None


def finish():
    global busy, message, _result
    if _result is None:
        return
    ok, text, mode = _result
    _result = None
    _timer.stop()
    busy = False
    message = text
    if ok and mode in ('enable', 'resume'):
        try:
            if mode == 'enable':
                if not lamedb_fix.reload_edvbdb():
                    raise RuntimeError('Service database reload failed')
                xc_setup.ENABLED.touch()
            autostart._session = session
            autostart._start_hook()
        except Exception as exc:
            xc_setup.ENABLED.unlink(missing_ok=True)
            disable_hook()
            message = 'Activation failed: %s' % exc
    logger.log(message)


def submit(mode):
    global busy, message, _result, _timer, _connection, _thread
    if busy: return
    if mode in ('enable', 'disable'):
        disable_hook()
        xc_setup.ENABLED.unlink(missing_ok=True)
    busy = True
    message = 'Preparing...' if mode == 'enable' else 'Working...'
    if _timer is None:
        _timer = eTimer(); _connection = connect_timer(_timer, finish)
    def worker():
        global _result
        try:
            if mode == 'enable':
                feeds, reload_cam = xc_setup.prepare()
                text = 'Enabled: %d feeds. Select an Abertis channel.' % feeds
                if reload_cam:
                    text += ' Restart your active OSCam once to load new A-rules.'
            elif mode == 'resume':
                xc_setup.check_tools(); xc_setup.start_astra()
                text = 'Enabled — automation ready'
            else:
                xc_setup.stop_astra(); text = 'Disabled'
            _result = (True, text, mode)
        except Exception as exc:
            _result = (False, 'Error: %s' % exc, mode)
    _thread = threading.Thread(target=worker, daemon=True)
    _thread.start(); _timer.start(250)


def session_start(reason=0, session=None, **kwargs):
    if reason != 0: return
    globals()['session'] = session
    if xc_setup.is_enabled(): submit('resume')
