"""Add only the bundled Abertis catalog; never replace the user's settings."""
import json
import os
from pathlib import Path
import shutil
import tempfile

HERE = Path(__file__).resolve().parent

def atomic(path, text):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix='.' + path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(text); f.flush(); os.fsync(f.fileno())
        os.chmod(name, 0o644)
        os.replace(name, path)
    finally:
        if os.path.exists(name): os.unlink(name)

def merge_database(text, feeds):
    lines = text.splitlines()
    if not lines or lines[0].strip() != 'eDVB services /4/':
        raise RuntimeError('Abertis catalog import requires lamedb v4; existing database left untouched')
    ta = lines.index('transponders') + 1
    tb = lines.index('end', ta)
    sa = lines.index('services', tb) + 1
    sb = lines.index('end', sa)
    transponders = {l.strip().lower() for l in lines[ta:tb] if l.count(':') == 2}
    services = {l.strip().lower() for l in lines[sa:sb] if l.count(':') >= 5}
    new_t, new_s = [], []
    for f in feeds:
        key = f['transponder'].splitlines()[0].lower()
        if key not in transponders:
            new_t.extend(f['transponder'].splitlines()); transponders.add(key)
        if f['id'].lower() not in services:
            new_s.extend([f['id'], f['name'], f['provider']]); services.add(f['id'].lower())
    result = lines[:tb] + new_t + lines[tb:sb] + new_s + lines[sb:]
    return '\n'.join(result) + '\n', len(new_s)//3

def install(settings=Path('/etc/enigma2'), backup=Path('/etc/xc-abertis/backup')):
    settings, backup = Path(settings), Path(backup)
    db = settings/'lamedb'
    feeds = json.loads((HERE/'data/feeds.json').read_text())
    merged, count = merge_database(db.read_text(encoding='utf-8'), feeds)
    bouquet = settings/'userbouquet.xc_abertis.tv'
    bouquets = settings/'bouquets.tv'
    index = bouquets.read_text() if bouquets.exists() else '#NAME Bouquets (TV)\n'
    marker = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.xc_abertis.tv" ORDER BY bouquet'
    if '"userbouquet.xc_abertis.tv"' not in index:
        index = index.rstrip()+'\n'+marker+'\n'
    backup.mkdir(parents=True, exist_ok=True); os.chmod(backup, 0o700)
    for p in (db, bouquet, bouquets):
        dest = backup/(p.name+'.before-catalog')
        if p.exists() and not dest.exists():
            shutil.copy2(p, dest); os.chmod(dest,0o600)
    atomic(db, merged)
    atomic(bouquet, (HERE/'data/userbouquet.xc_abertis.tv').read_text())
    atomic(bouquets, index)
    return count
