"""OSCam capability and append-only EMU integration. No binary replacement."""
from pathlib import Path
import re
import subprocess


def sections(text, name):
    parts = re.split(r'(?m)^\s*\[([^]\r\n]+)\]\s*$', text)
    for i in range(1, len(parts), 2):
        if parts[i].strip().lower() != name:
            continue
        result = {}
        for line in parts[i+1].splitlines():
            if '=' not in line or line.lstrip().startswith(('#', ';')):
                continue
            k,v=line.split('=',1);result[k.strip().lower()]=v.split('#',1)[0].split(';',1)[0].strip()
        yield result


def features(exe):
    p = subprocess.run([str(exe), '-V'], stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=5, text=True)
    output = p.stdout
    if p.returncode:
        raise RuntimeError('Cannot inspect running OSCam capabilities (-V failed)')
    for label in ('DVB API support', 'Emulator support'):
        if not re.search(r'^'+re.escape(label)+r'\s*:\s*yes\s*$', output, re.I|re.M):
            raise RuntimeError('Running OSCam lacks '+label+'; its binary was not replaced')
    match = re.search(r'^ConfigDir:\s*(.+)$', output, re.M)
    return match.group(1).strip() if match else None


def reader_plan(server, user, conf):
    """Reuse an enabled EMU reader only if it permits BISS and the DVBAPI user."""
    dvb = next(sections(conf,'dvbapi'), {})
    if dvb.get('enabled', '0') != '1':
        raise RuntimeError('Enable DVBAPI in the active OSCam first; existing policy left unchanged')
    username = dvb.get('user')
    accounts = list(sections(user,'account'))
    account = next((a for a in accounts if a.get('user') == username), None)
    if not username or account is None:
        raise RuntimeError('Active OSCam DVBAPI user has no matching account; configure it first')
    groups = {g.strip() for g in account.get('group','').split(',') if g.strip().isdigit() and 1<=int(g.strip())<=64}
    if not groups:
        raise RuntimeError('DVBAPI account has no valid reader group')
    for r in sections(server,'reader'):
        if r.get('protocol','').lower() != 'emu' or r.get('enable','1') == '0':
            continue
        caids = [c.strip().upper() for c in r.get('caid','').split(',') if c.strip()]
        if caids and '2600' not in caids:
            continue
        if groups.intersection(g.strip() for g in r.get('group','').split(',')) and not r.get('services'):
            return None
    if any(r.get('label') == 'XC_Abertis' for r in sections(server,'reader')):
        raise RuntimeError('Existing XC_Abertis reader is incompatible; inspect its groups/CAID instead of duplicating it')
    group = sorted(groups,key=int)[0]
    return '\n[reader]\nlabel = XC_Abertis\nprotocol = emu\ndevice = emulator\ncaid = 2600\ngroup = '+group+'\n'


def ensure_reader(directory, backup, atomic_write):
    directory=Path(directory)
    paths = {name:directory/('oscam.'+name) for name in ('server','user','conf')}
    text = {name:p.read_text() if p.exists() else '' for name,p in paths.items()}
    block=reader_plan(text['server'],text['user'],text['conf'])
    if block is None:
        return False
    backup(paths['server'])
    atomic_write(str(paths['server']), (text['server'].rstrip()+'\n'+block).encode(), 0o600)
    return True


def account_plan(server, user, conf):
    """Complete only the local DVBAPI account and enabled/user settings."""
    dvb = next(sections(conf, 'dvbapi'), {})
    username = dvb.get('user') or 'xc_abertis'
    # Values are written as plain config values; reject malformed names.
    if not re.fullmatch(r'[A-Za-z0-9_.@-]{1,64}', username):
        raise RuntimeError('Unsupported DVBAPI username syntax; configuration left untouched')
    account = next((a for a in sections(user,'account') if a.get('user')==username), None)
    if account is None:
        groups = {g.strip() for r in sections(server,'reader') for g in r.get('group','').split(',')
                  if g.strip().isdigit() and 1<=int(g.strip())<=64} or {'1'}
        user = user.rstrip()+'\n\n[account]\nuser = '+username+'\ngroup = '+','.join(sorted(groups,key=int))+'\nau = 1\n'
    lines = conf.splitlines(keepends=True)
    start = next((i for i,l in enumerate(lines) if re.fullmatch(r'\s*\[dvbapi\]\s*', l, re.I)), None)
    if start is None:
        conf = conf.rstrip()+'\n\n[dvbapi]\nenabled = 1\nuser = '+username+'\n'
    else:
        end = next((i for i in range(start+1,len(lines)) if lines[i].lstrip().startswith('[')),len(lines))
        block = lines[start+1:end]
        for key, value in [('enabled','1'), ('user',username)]:
            hits=[i for i,l in enumerate(block) if re.match(r'^\s*'+key+r'\s*=',l,re.I)]
            if hits:
                for i in hits: block[i]=key+' = '+value+'\n'
            else: block.append(key+' = '+value+'\n')
        conf=''.join(lines[:start+1]+block+lines[end:])
    return user, conf


def ensure_account(directory, backup, atomic_write):
    directory=Path(directory)
    texts={n:(directory/('oscam.'+n)).read_text() if (directory/('oscam.'+n)).exists() else ''
           for n in ('server','user','conf')}
    user,conf=account_plan(texts['server'],texts['user'],texts['conf'])
    # Validate the complete resulting plan before any write.
    reader_plan(texts['server'],user,conf)
    changed=False
    for name,new in [('user',user),('conf',conf)]:
        if new != texts[name]:
            path=directory/('oscam.'+name);backup(path)
            atomic_write(str(path),new.encode(),0o600);changed=True
    return changed
