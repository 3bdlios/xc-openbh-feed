"""XC-specific opt-in setup. No global tool, boot or CAM binary replacement."""
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
CONFIG = Path('/etc/xc-abertis')
ENABLED = CONFIG / 'enabled'
BACKUP = CONFIG / 'backup'
PIDFILE = Path('/run/xc-abertis.pid')
VERSION = '1.1.0'


def is_enabled():
    return ENABLED.exists()


def command(args, timeout=15):
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          timeout=timeout, text=True, check=True).stdout.strip()


def backup(path):
    path = Path(path)
    BACKUP.mkdir(parents=True, exist_ok=True)
    os.chmod(BACKUP, 0o700)
    dest = BACKUP / str(path).lstrip('/').replace('/', '__')
    if path.exists() and not dest.exists():
        shutil.copy2(path, dest)
        os.chmod(dest, 0o600)


def active_cam():
    """Resolve a single running OSCam and its actual -c/--config-dir."""
    found = []
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            exe = Path(os.readlink(proc / 'exe')).name.lower()
            if 'oscam' not in exe:
                continue
            args = (proc / 'cmdline').read_bytes().split(b'\0')
            args = [s.decode('utf-8', 'replace') for s in args if s]
            directory = None
            for i, arg in enumerate(args):
                if arg in ('-c', '--config-dir') and i+1 < len(args):
                    directory = args[i+1]
                elif arg.startswith('--config-dir='):
                    directory = arg.split('=', 1)[1]
                elif arg.startswith('-c') and len(arg)>2:
                    directory = arg[2:]
            if directory is None:
                from .cam_support import features
                directory = features(os.readlink(proc / 'exe'))
            if directory and Path(directory).is_dir():
                found.append((str(Path(os.readlink(proc / 'exe')).resolve()), str(Path(directory).resolve())))
        except (OSError, ValueError):
            continue
    found = sorted(set(found))
    if len(found) != 1:
        raise RuntimeError('One unambiguous running OSCam/config directory is required')
    from .cam_support import features
    features(found[0][0])
    return Path(found[0][1])


def check_tools():
    if platform.machine().lower() not in ('aarch64', 'arm64'):
        raise RuntimeError('This XC build requires ARM64 / aarch64')
    for tool in ('astra', 'abertis'):
        # Dynamic loader checks dependencies without running a stream.
        command(['/lib/ld-linux-aarch64.so.1', '--library-path', str(HERE/'lib'),
                 '--list', str(HERE/'bin'/tool)])


def _pid():
    try:
        pid = int(PIDFILE.read_text())
        if Path('/proc/%d/exe' % pid).resolve() == (HERE/'bin/astra').resolve():
            return pid
    except (OSError, ValueError):
        pass
    return None


def stop_astra():
    import signal
    pid = _pid()
    if pid:
        os.kill(pid, signal.SIGTERM)
        for _ in range(20):
            if _pid() is None:
                break
            time.sleep(0.1)
        if _pid() is not None:
            raise RuntimeError('XC Astra did not stop; no forced kill was sent')
    PIDFILE.unlink(missing_ok=True)


def start_astra():
    if _pid():
        return
    import socket
    probe = socket.socket()
    try:
        probe.bind(('0.0.0.0', 9999))
    except OSError:
        raise RuntimeError('Port 9999 is in use; existing service left untouched')
    finally:
        probe.close()
    env = os.environ.copy()
    env['LD_LIBRARY_PATH'] = str(HERE/'lib') + (':' + env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    with open('/tmp/xc-abertis-astra.log', 'ab') as log:
        process = subprocess.Popen([str(HERE/'bin/astra'), '--pid', str(PIDFILE),
            '--log', '/tmp/xc-abertis-astra.log', str(CONFIG/'astra.conf')],
            stdin=subprocess.DEVNULL, stdout=log, stderr=log, env=env,
            start_new_session=True)
    PIDFILE.write_text(str(process.pid))
    time.sleep(0.4)
    if process.poll() is not None:
        PIDFILE.unlink(missing_ok=True)
        raise RuntimeError('Astra failed to start; see /tmp/xc-abertis-astra.log')


def prepare():
    from . import setup, lamedb_fix
    check_tools()
    feeds = lamedb_fix.get_all_feeds()
    if not feeds:
        raise RuntimeError('No Abertis PID feeds in lamedb. Install your Hispasat bouquet first.')
    cam = active_cam()
    from .cam_support import ensure_reader, ensure_account, reader_plan, account_plan
    # Validate accounts and groups before writing any configuration.
    cam_text = [(cam/('oscam.'+n)).read_text() if (cam/('oscam.'+n)).exists() else '' for n in ('server','user','conf')]
    planned_user, planned_conf = account_plan(*cam_text)
    reader_plan(cam_text[0], planned_user, planned_conf)
    CONFIG.mkdir(parents=True, exist_ok=True)
    for p in (Path(lamedb_fix.LAMEDB), cam/'oscam.dvbapi', cam/'SoftCam.Key', CONFIG/'astra.conf'):
        backup(p)
    setup.OSCAM_DVBAPI = str(cam/'oscam.dvbapi')
    setup.OSCAM_DVBAPI_BACKUP = str(BACKUP/'oscam.dvbapi.original')
    ok, changed, message = setup.ensure_oscam_dvbapi_a_rules(rules=lamedb_fix.build_a_rules(feeds))
    if not ok:
        raise RuntimeError(message)
    changed = ensure_account(cam, backup, setup._atomic_write) or changed
    changed = ensure_reader(cam, backup, setup._atomic_write) or changed
    # Astra gets its own key file; append missing Abertis keys to the active
    # CAM file without copying subscription settings into this package.
    for target in (CONFIG/'softcam.key', cam/'SoftCam.Key', cam/'softcam.key'):
        old = target.read_text() if target.exists() else ''
        have = {setup._normalize_key_line(l) for l in old.splitlines()}
        add = [l for l in setup.ABERTIS_KEYS.splitlines() if l.strip() and setup._normalize_key_line(l) not in have]
        if add:
            setup._atomic_write(str(target), (old.rstrip()+'\n'+'\n'.join(add)+'\n').encode(), 0o600)
    if not setup.ensure_astra_conf():
        raise RuntimeError('Cannot prepare private Astra configuration')
    setup.sanitize_astra_conf()
    ok, _, message = setup.ensure_astra_streams(feeds=feeds)
    if not ok:
        raise RuntimeError(message)
    # All mutations are limited to matching Abertis feeds. No fixed service zap.
    count = 0
    for feed in feeds:
        changed_feed, detail = lamedb_fix.set_feed_mode(feed['pid'], 'f5')
        if detail.startswith('ERROR'):
            raise RuntimeError(detail)
        count += int(changed_feed)
    (CONFIG/'last-setup.json').write_text(json.dumps({'version': VERSION,
        'feeds': len(feeds), 'services_changed': count, 'cam_config': str(cam),
        'cam_reload_required': changed, 'time': time.time()}, indent=2))
    start_astra()
    return len(feeds), changed


def install_overrides(namespace):
    namespace['ASTRA_CONF'] = str(CONFIG/'astra.conf')
    namespace['ASTRA_CONF_BACKUP'] = str(BACKUP/'astra.conf.original')
    namespace['SOFTCAM_KEY_UPPER'] = str(CONFIG/'SoftCam.Key.unused')
    namespace['SOFTCAM_KEY'] = str(CONFIG/'softcam.key')
    namespace['ASTRA_BIN'] = str(HERE/'bin/astra')
    namespace['ASTRA_BIN_CANDIDATES'] = [str(HERE/'bin/astra')]
    original = namespace['astra_stream_block']
    def stream(pid, ref):
        return original(pid, ref).replace('/etc/astra/scripts/abertis', str(HERE/'bin/abertis'))
    namespace['astra_stream_block'] = stream
    # Original engine calls these while preparing feeds; they act only on
    # this private Astra process and never install/start a second OSCam.
    def restart():
        try:
            stop_astra(); start_astra()
            return True, 'XC Astra restarted'
        except Exception as exc:
            return False, str(exc)
    namespace['controlled_astra_restart'] = restart
    namespace['restart_astra'] = lambda: restart()[0]
    namespace['run_full_setup'] = lambda restart_configs=True: prepare()[0]
