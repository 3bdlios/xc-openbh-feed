from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config
from enigma import eTimer, eDVBDB
from .compat import connect_timer
from . import runtime, xc_setup, lamedb_fix, logger, catalog


def tr(english, arabic):
    return arabic if config.osd.language.value.startswith('ar') else english


class XCAbertisScreen(Screen):
    skin = '''<screen name="XCAbertisScreen" position="center,center" size="1020,570" resolution="1920,1080" title="XC Abertis" backgroundColor="#00101824">
    <widget name="title" position="40,30" size="940,55" font="Regular;38" foregroundColor="#0057d8cb" backgroundColor="#00101824" />
    <widget name="subtitle" position="40,95" size="940,45" font="Regular;23" foregroundColor="#00b0bfce" backgroundColor="#00101824" />
    <widget name="status" position="40,165" size="940,140" font="Regular;25" foregroundColor="#00ffffff" backgroundColor="#001b2c3b" />
    <widget name="help" position="40,330" size="940,100" font="Regular;22" foregroundColor="#00b0bfce" backgroundColor="#00101824" />
    <widget name="red" position="40,475" size="220,50" font="Regular;22" halign="center" valign="center" foregroundColor="#00ffffff" backgroundColor="#009c3541" />
    <widget name="green" position="280,475" size="220,50" font="Regular;22" halign="center" valign="center" foregroundColor="#00ffffff" backgroundColor="#00266d58" />
    <widget name="yellow" position="520,475" size="220,50" font="Regular;22" halign="center" valign="center" foregroundColor="#00101824" backgroundColor="#00d8ba58" />
    <widget name="blue" position="760,475" size="220,50" font="Regular;22" halign="center" valign="center" foregroundColor="#00ffffff" backgroundColor="#003c648a" />
    </screen>'''

    def __init__(self, session):
        Screen.__init__(self, session)
        self['title'] = Label('XC ABERTIS  /  1.1.0 TEST')
        self['subtitle'] = Label(tr('Abertis / Hispasat 30W • XC ARM64 • Python 3', 'أبرتيس / هيسباسات 30 غرب • XC ARM64'))
        self['status'] = Label('')
        self['help'] = Label(tr('Green: prepare and enable. Yellow: disable. Blue / OK: diagnostics.\nAdds only the Abertis bouquet; preserves other channels. Your active OSCam is never replaced.', 'الأخضر: إعداد وتفعيل. الأصفر: تعطيل. الأزرق: تشخيص.\nيضيف قائمة أبرتيس ويحافظ على قنواتك؛ لا يستبدل الأوسكام الحالي.'))
        for name, en, ar in [('red','Close','إغلاق'),('green','Enable','تفعيل'),('yellow','Disable','تعطيل'),('blue','Diagnostics','تشخيص')]:
            self[name] = Label(tr(en, ar))
        self['actions'] = ActionMap(['ColorActions','OkCancelActions'], {
            'red':self.close, 'cancel':self.close, 'green':self.enable,
            'yellow':self.disable, 'blue':self.diagnostics, 'ok':self.diagnostics}, -1)
        self.timer=eTimer();self.connection=connect_timer(self.timer,self.refresh)
        self.timer.start(500);self.onClose.append(self.timer.stop)
        self.refresh()

    def refresh(self):
        text = runtime.message
        if self['status'].getText() != text: self['status'].setText(text)

    def enable(self):
        runtime.session=self.session
        if runtime.busy:
            return
        try:
            # Save the live database on the GUI thread before merging additions.
            db=eDVBDB.getInstance()
            db.saveServicelist()
            added=catalog.install()
            db.reloadServicelist()
            db.reloadBouquets()
            logger.log('Abertis catalog installed: %d new feeds' % added)
        except Exception as exc:
            runtime.message='Catalog error: %s' % exc
            self.refresh()
            return
        runtime.submit('enable');self.refresh()

    def disable(self):
        runtime.submit('disable');self.refresh()

    def diagnostics(self):
        feeds=lamedb_fix.get_all_feeds()
        text='XC Abertis %s TEST\nEnabled: %s\nFeeds: %d\nAstra running: %s\nStream source: 8001\nOutput: 9999\n\n%s\n\n%s' % (
            xc_setup.VERSION,xc_setup.is_enabled(),len(feeds),bool(xc_setup._pid()),runtime.message,logger.tail(8))
        self.session.open(MessageBox,text,type=MessageBox.TYPE_INFO)


def main(session, **kwargs):
    session.open(XCAbertisScreen)


def Plugins(**kwargs):
    return [PluginDescriptor(name='XC Abertis',description='XC Abertis / Hispasat 30W — TEST',
        where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png',fnc=main),
        PluginDescriptor(name='XC Abertis',where=PluginDescriptor.WHERE_SESSIONSTART,fnc=runtime.session_start)]
