import importlib.util
from pathlib import Path
import unittest
p=Path(__file__).parent/'package/usr/lib/enigma2/python/Plugins/Extensions/XCAbertis/cam_support.py'
s=importlib.util.spec_from_file_location('cam',p);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
class Tests(unittest.TestCase):
 def test_reuses_reader_and_preserves_config(self):
  server='[reader]\nprotocol=emu\ngroup=2\ncaid=2600\n'
  self.assertIsNone(c.reader_plan(server,'[account]\nuser=tv\ngroup=2\n','[dvbapi]\nenabled=1\nuser=tv\n'))
 def test_append_matches_existing_group(self):
  block=c.reader_plan('','[account]\nuser=tv\ngroup=7\n','[dvbapi]\nenabled=1\nuser=tv\n')
  self.assertIn('group = 7',block)
 def test_rejects_missing_user(self):
  with self.assertRaises(RuntimeError): c.reader_plan('','','[dvbapi]\nenabled=1\nuser=tv\n')
 def test_disabled_reader_not_reused(self):
  self.assertIsNotNone(c.reader_plan('[reader]\nprotocol=emu\ngroup=2\nenable=0\n','[account]\nuser=tv\ngroup=2\n','[dvbapi]\nenabled=1\nuser=tv\n'))
class AccountTests(unittest.TestCase):
 def test_missing_local_account_is_completed(self):
  server='[reader]\nprotocol=cccam\ngroup=2,3\n'
  user,conf=c.account_plan(server,'','[dvbapi]\nenabled=1\nuser=local\n')
  self.assertIn('user = local',user);self.assertIn('group = 2,3',user)
  self.assertIsNotNone(c.reader_plan(server,user,conf))
 def test_existing_accounts_and_reader_settings_untouched(self):
  user='[account]\nuser=local\ngroup=7\npassword=example\n'
  conf='[global]\nlogfile=/tmp/test\n[dvbapi]\nenabled=1\nuser=local\nboxtype=pc\n'
  a,b=c.account_plan('',user,conf)
  self.assertEqual(a,user);self.assertIn('boxtype=pc',b)
  self.assertEqual((a,b),c.account_plan('',a,b))
if __name__=='__main__':unittest.main()
